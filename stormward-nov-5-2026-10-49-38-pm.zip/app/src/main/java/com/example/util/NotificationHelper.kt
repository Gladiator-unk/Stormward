package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.data.model.AlertSeverity
import com.example.data.model.SevereAlert

object NotificationHelper {
    const val CHANNEL_ID = "stormward_severe_channel"
    private const val CHANNEL_NAME = "Severe Weather Emergency Alerts"
    private const val CHANNEL_DESC = "Urgent notifications for incoming severe storms, tornadoes, and flash floods."

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = CHANNEL_DESC
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 700)
                setShowBadge(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun sendSevereAlertNotification(
        context: Context,
        alert: SevereAlert,
        vibrationEnabled: Boolean = true,
        soundEnabled: Boolean = true
    ): Boolean {
        createNotificationChannel(context)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return false
            }
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("ALERT_ID", alert.id)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            alert.id.hashCode(),
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val soundUri = if (soundEnabled) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) else null

        val priorityLevel = when (alert.severity) {
            AlertSeverity.EXTREME -> NotificationCompat.PRIORITY_MAX
            AlertSeverity.SEVERE -> NotificationCompat.PRIORITY_HIGH
            else -> NotificationCompat.PRIORITY_DEFAULT
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("⚠️ ${alert.title.uppercase()}")
            .setContentText(alert.headline)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("${alert.headline}\n\n📍 Impact Area: ${alert.affectedZones.joinToString(", ")}\n⚡ Peak Wind: ${alert.maxWindGustMph} mph | Hail: ${alert.hailSizeInches}\"\n🛡️ ACTION: ${alert.actionRecommended}")
            )
            .setPriority(priorityLevel)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        if (soundUri != null) {
            builder.setSound(soundUri)
        }
        if (vibrationEnabled) {
            builder.setVibrate(longArrayOf(0, 400, 200, 400, 200, 600))
        }

        return try {
            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify(alert.id.hashCode(), builder.build())
            true
        } catch (e: SecurityException) {
            false
        }
    }
}

package com.example.util

import android.content.Context
import android.content.Intent
import com.example.data.local.IncidentReportEntity
import com.example.data.model.SevereAlert

object ShareHelper {
    fun shareSevereAlert(context: Context, alert: SevereAlert) {
        val shareBody = """
            ⚠️ URGENT WEATHER ALERT: ${alert.title.uppercase()}
            
            ${alert.headline}
            
            📍 Affected Zones: ${alert.affectedZones.joinToString(", ")}
            💨 Max Winds: Up to ${alert.maxWindGustMph} mph
            🧊 Hail Hazard: ${alert.hailSizeInches}" diameter
            ⏰ Effective until: ${alert.expiresTime}
            
            🛡️ Recommended Safety Action:
            ${alert.actionRecommended}
            
            -- Monitored live via StormWard (made by Gladiator.unk aka Shaik UzairUzair)
        """.trimIndent()

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "⚠️ Severe Weather Alert: ${alert.title}")
            putExtra(Intent.EXTRA_TEXT, shareBody)
        }
        context.startActivity(Intent.createChooser(intent, "Share Severe Storm Alert"))
    }

    fun shareIncidentReport(context: Context, report: IncidentReportEntity) {
        val shareBody = """
            🚨 STORM INCIDENT REPORT: ${report.title}
            
            📍 Location: ${report.locationName} (${report.distanceMiles} miles away)
            ⚠️ Category: ${report.incidentType.replace('_', ' ')} [${report.severityLevel}]
            ⏱️ Reported at: ${report.timestampFormatted}
            📊 Measurement: ${report.hailSizeOrFloodDepth}
            
            📝 Field Observations:
            "${report.description}"
            
            👤 Reported by: ${report.reporterName} ${if (report.isVerifiedSpotter) "✓ (Verified Spotter)" else ""}
            👍 Confirmed by ${report.upvoteCount} local community members
            
            -- Shared via StormWard Community Network (made by Gladiator.unk aka Shaik UzairUzair)
        """.trimIndent()

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "🚨 Community Storm Incident: ${report.title}")
            putExtra(Intent.EXTRA_TEXT, shareBody)
        }
        context.startActivity(Intent.createChooser(intent, "Share Incident with Community"))
    }
}

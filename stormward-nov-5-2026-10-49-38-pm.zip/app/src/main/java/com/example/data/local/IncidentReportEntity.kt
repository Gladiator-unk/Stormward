package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "incident_reports")
data class IncidentReportEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val incidentType: String, // TORNADO_SIGHTING, LARGE_HAIL, DOWNED_POWERLINE, FLASH_FLOOD, STRUCTURAL_DAMAGE, FUNNEL_CLOUD
    val severityLevel: String, // CRITICAL, HIGH, MODERATE, LOW
    val description: String,
    val locationName: String,
    val distanceMiles: Float,
    val hailSizeOrFloodDepth: String,
    val timestampFormatted: String,
    val reportedEpochMs: Long = System.currentTimeMillis(),
    val reporterName: String,
    val isVerifiedSpotter: Boolean = false,
    val upvoteCount: Int = 0,
    val hasUserUpvoted: Boolean = false
)

package com.example.data.repository

import com.example.data.local.IncidentReportDao
import com.example.data.local.IncidentReportEntity
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

data class MonitoredCity(
    val id: String,
    val name: String,
    val state: String,
    val lat: Double,
    val lng: Double,
    val defaultRisk: SevereRiskLevel
)

class WeatherRepository(private val dao: IncidentReportDao) {

    val availableCities = listOf(
        MonitoredCity("okc", "Oklahoma City", "OK", 35.4676, -97.5164, SevereRiskLevel.EXTREME),
        MonitoredCity("dfw", "Dallas-Fort Worth", "TX", 32.7767, -96.7970, SevereRiskLevel.HIGH),
        MonitoredCity("mia", "Miami Metro", "FL", 25.7617, -80.1918, SevereRiskLevel.ENHANCED),
        MonitoredCity("chi", "Chicago Lakefront", "IL", 41.8781, -87.6298, SevereRiskLevel.SLIGHT),
        MonitoredCity("den", "Denver High Plains", "CO", 39.7392, -104.9903, SevereRiskLevel.MARGINAL)
    )

    fun getCurrentWeather(cityId: String): CurrentWeather {
        return when (cityId) {
            "okc" -> CurrentWeather(
                locationName = "Oklahoma City",
                stateCode = "OK",
                latitude = 35.4676,
                longitude = -97.5164,
                tempF = 78,
                feelsLikeF = 84,
                condition = "Severe Supercell Approaching",
                humidityPercent = 82,
                windSpeedMph = 38,
                windDirection = "SSW",
                windGustMph = 68,
                pressureHpa = 994.2f,
                pressureTrend = PressureTrend.FALLING_RAPIDLY,
                dewPointF = 71,
                uvIndex = 3,
                visibilityMiles = 2.4f,
                severeRiskLevel = SevereRiskLevel.EXTREME,
                lightningStrikesNearby = 142,
                radarReflectivityDbz = 64
            )
            "dfw" -> CurrentWeather(
                locationName = "Dallas-Fort Worth",
                stateCode = "TX",
                latitude = 32.7767,
                longitude = -96.7970,
                tempF = 81,
                feelsLikeF = 87,
                condition = "Squall Line / High Wind",
                humidityPercent = 76,
                windSpeedMph = 29,
                windDirection = "WNW",
                windGustMph = 54,
                pressureHpa = 1002.8f,
                pressureTrend = PressureTrend.FALLING,
                dewPointF = 68,
                uvIndex = 5,
                visibilityMiles = 5.0f,
                severeRiskLevel = SevereRiskLevel.HIGH,
                lightningStrikesNearby = 88,
                radarReflectivityDbz = 52
            )
            "mia" -> CurrentWeather(
                locationName = "Miami Metro",
                stateCode = "FL",
                latitude = 25.7617,
                longitude = -80.1918,
                tempF = 86,
                feelsLikeF = 95,
                condition = "Tropical Squalls & Heavy Rain",
                humidityPercent = 89,
                windSpeedMph = 32,
                windDirection = "ENE",
                windGustMph = 48,
                pressureHpa = 1004.5f,
                pressureTrend = PressureTrend.FALLING,
                dewPointF = 75,
                uvIndex = 6,
                visibilityMiles = 4.2f,
                severeRiskLevel = SevereRiskLevel.ENHANCED,
                lightningStrikesNearby = 64,
                radarReflectivityDbz = 48
            )
            "chi" -> CurrentWeather(
                locationName = "Chicago Lakefront",
                stateCode = "IL",
                latitude = 41.8781,
                longitude = -87.6298,
                tempF = 62,
                feelsLikeF = 59,
                condition = "Lakefront Gale / Rainbands",
                humidityPercent = 71,
                windSpeedMph = 26,
                windDirection = "NNE",
                windGustMph = 42,
                pressureHpa = 1011.0f,
                pressureTrend = PressureTrend.STEADY,
                dewPointF = 52,
                uvIndex = 4,
                visibilityMiles = 7.5f,
                severeRiskLevel = SevereRiskLevel.SLIGHT,
                lightningStrikesNearby = 19,
                radarReflectivityDbz = 36
            )
            else -> CurrentWeather(
                locationName = "Denver High Plains",
                stateCode = "CO",
                latitude = 39.7392,
                longitude = -104.9903,
                tempF = 68,
                feelsLikeF = 66,
                condition = "Isolated Hail Cells",
                humidityPercent = 48,
                windSpeedMph = 18,
                windDirection = "W",
                windGustMph = 35,
                pressureHpa = 1014.2f,
                pressureTrend = PressureTrend.RISING,
                dewPointF = 42,
                uvIndex = 7,
                visibilityMiles = 10.0f,
                severeRiskLevel = SevereRiskLevel.MARGINAL,
                lightningStrikesNearby = 12,
                radarReflectivityDbz = 28
            )
        }
    }

    fun getActiveAlerts(cityId: String): List<SevereAlert> {
        return when (cityId) {
            "okc" -> listOf(
                SevereAlert(
                    id = "alert_okc_tor",
                    hazardType = HazardType.TORNADO,
                    severity = AlertSeverity.EXTREME,
                    title = "Tornado Warning (Confirmed Rotation)",
                    headline = "Severe storm capable of producing a destructive tornado moving northeast at 45 mph.",
                    issuedTime = "10 mins ago",
                    expiresTime = "In 38 minutes (09:15 AM)",
                    description = "Doppler radar indicated a confirmed developing cyclonic mesocyclone with gate-to-gate shear of 84 knots. Flying debris will be dangerous to those caught without shelter.",
                    actionRecommended = "TAKE COVER NOW! Move to an interior room on the lowest floor of a sturdy building. Avoid windows. If in a mobile home or vehicle, evacuate to the nearest designated shelter.",
                    affectedZones = listOf("Oklahoma County", "Canadian County", "Cleveland County", "Moore", "Norman"),
                    maxWindGustMph = 85,
                    hailSizeInches = 2.5f,
                    distanceMiles = 6.2f,
                    bearing = "SW moving NE"
                ),
                SevereAlert(
                    id = "alert_okc_hail",
                    hazardType = HazardType.HAIL,
                    severity = AlertSeverity.SEVERE,
                    title = "Destructive Baseball-Size Hail Warning",
                    headline = "Supercell core producing 2.75 inch hail stones detected along Interstate 35.",
                    issuedTime = "18 mins ago",
                    expiresTime = "In 55 minutes (09:30 AM)",
                    description = "Severe thunderstorm with massive vertical updraft capable of catastrophic vehicle and roof damage.",
                    actionRecommended = "Park vehicles under reinforced garage cover. Stay away from glass skylights and windows.",
                    affectedZones = listOf("Edmond", "Guthrie", "North OKC"),
                    maxWindGustMph = 65,
                    hailSizeInches = 2.75f,
                    distanceMiles = 8.5f,
                    bearing = "W moving E"
                ),
                SevereAlert(
                    id = "alert_okc_flood",
                    hazardType = HazardType.FLASH_FLOOD,
                    severity = AlertSeverity.MODERATE,
                    title = "Flash Flood Warning",
                    headline = "Rainfall rates of 2.8 inches per hour resulting in rapid urban street inundation.",
                    issuedTime = "25 mins ago",
                    expiresTime = "In 2 hours",
                    description = "Low-lying underpasses and storm drainage networks are overflowing. Deep standing water on roadways.",
                    actionRecommended = "Turn around, don't drown! Never drive through flooded roads or underpasses.",
                    affectedZones = listOf("Deep Fork Creek basin", "Western Avenue corridors"),
                    maxWindGustMph = 45,
                    hailSizeInches = 0.5f,
                    distanceMiles = 3.1f,
                    bearing = "Stationary"
                )
            )
            "dfw" -> listOf(
                SevereAlert(
                    id = "alert_dfw_wind",
                    hazardType = HazardType.HIGH_WIND,
                    severity = AlertSeverity.SEVERE,
                    title = "Severe Thunderstorm / Straight-Line Winds",
                    headline = "Dangerous bow echo tracking across Tarrant and Dallas counties with 70 mph gusts.",
                    issuedTime = "12 mins ago",
                    expiresTime = "In 40 minutes",
                    description = "Widespread tree damage and downed power transmission lines reported.",
                    actionRecommended = "Secure loose outdoor furniture and stay inside interior rooms away from large trees.",
                    affectedZones = listOf("Fort Worth", "Arlington", "Dallas"),
                    maxWindGustMph = 72,
                    hailSizeInches = 1.75f,
                    distanceMiles = 9.8f,
                    bearing = "NW moving SE"
                )
            )
            "mia" -> listOf(
                SevereAlert(
                    id = "alert_mia_hurr",
                    hazardType = HazardType.HURRICANE,
                    severity = AlertSeverity.SEVERE,
                    title = "Tropical Squall & Surge Advisory",
                    headline = "Bands of tropical squalls producing localized water spouts and coastal flooding.",
                    issuedTime = "30 mins ago",
                    expiresTime = "In 4 hours",
                    description = "Coastal tidal surge of 2-3 feet accompanied by blinding tropical downpours.",
                    actionRecommended = "Avoid coastal causeways and secure small marine craft.",
                    affectedZones = listOf("Biscayne Bay", "Miami Beach", "Key Biscayne"),
                    maxWindGustMph = 58,
                    hailSizeInches = 0.0f,
                    distanceMiles = 4.5f,
                    bearing = "SE moving NW"
                )
            )
            else -> listOf(
                SevereAlert(
                    id = "alert_generic",
                    hazardType = HazardType.HIGH_WIND,
                    severity = AlertSeverity.MODERATE,
                    title = "Wind Advisory",
                    headline = "Gusty boundary winds expected ahead of dry frontal passage.",
                    issuedTime = "1 hour ago",
                    expiresTime = "In 3 hours",
                    description = "Sustained winds 25 to 35 mph with peak gusts to 45 mph.",
                    actionRecommended = "Exercise caution when operating high-profile vehicles.",
                    affectedZones = listOf("Metro Area", "Outer Foothills"),
                    maxWindGustMph = 48,
                    hailSizeInches = 0.0f,
                    distanceMiles = 12.0f,
                    bearing = "W moving E"
                )
            )
        }
    }

    fun getHourlyForecast(cityId: String): List<HourlyForecast> {
        return listOf(
            HourlyForecast("Now", 78, 95, "Severe Storm", 38, true),
            HourlyForecast("+1 hr", 74, 90, "Heavy Rain / Hail", 34, true),
            HourlyForecast("+2 hr", 71, 75, "Thunderstorm", 28, true),
            HourlyForecast("+3 hr", 69, 50, "Passing Squall", 22, false),
            HourlyForecast("+4 hr", 68, 30, "Showers Ending", 18, false),
            HourlyForecast("+5 hr", 66, 15, "Cloudy Clearing", 14, false),
            HourlyForecast("+6 hr", 65, 10, "Partly Cloudy", 10, false),
            HourlyForecast("+7 hr", 64, 5, "Clear Skies", 8, false)
        )
    }

    fun getDailyForecast(cityId: String): List<DailyForecast> {
        return listOf(
            DailyForecast("Today", 79, 62, 95, "Severe Storm Outbreak", SevereRiskLevel.EXTREME),
            DailyForecast("Thu", 74, 58, 45, "Scattered Storms", SevereRiskLevel.SLIGHT),
            DailyForecast("Fri", 78, 60, 20, "Partly Sunny", SevereRiskLevel.LOW),
            DailyForecast("Sat", 82, 64, 60, "Afternoon Supercells", SevereRiskLevel.ENHANCED),
            DailyForecast("Sun", 80, 63, 70, "Squall Line", SevereRiskLevel.HIGH),
            DailyForecast("Mon", 76, 59, 30, "Passing Showers", SevereRiskLevel.MARGINAL),
            DailyForecast("Tue", 75, 57, 10, "Clear & Calm", SevereRiskLevel.LOW)
        )
    }

    fun getAirQuality(cityId: String): AirQualityData {
        return when (cityId) {
            "okc" -> AirQualityData(
                aqi = 64,
                category = AqiCategory.MODERATE,
                dominantPollutant = "PM10 (Dust & Storm Loft)",
                pm25 = 14.2f,
                pm10 = 58.4f,
                o3 = 34.0f,
                no2 = 18.2f,
                co = 0.4f,
                so2 = 2.1f,
                healthAdvice = "Turbulent outflow winds are lofting surface particulates. Keep windows closed while storms pass.",
                maskRecommended = false,
                surroundingStations = listOf(
                    SurroundingAqiStation("okc_dt", "Downtown Metro Station", 1.8f, "Center", 64, AqiCategory.MODERATE, "PM10", "Rising (+4/hr)"),
                    SurroundingAqiStation("okc_edm", "Edmond North Station", 8.4f, "North", 48, AqiCategory.GOOD, "PM2.5", "Stable"),
                    SurroundingAqiStation("okc_mwr", "Moore South Radar Station", 6.1f, "South", 86, AqiCategory.MODERATE, "PM10 (Dust)", "Rising (+9/hr)"),
                    SurroundingAqiStation("okc_mwc", "Midwest City Industrial", 5.2f, "East", 72, AqiCategory.MODERATE, "Ozone", "Falling (-3/hr)"),
                    SurroundingAqiStation("okc_yuk", "Yukon Outflow Basin", 9.5f, "West", 112, AqiCategory.UNHEALTHY_SENSITIVE, "PM10 (Outflow)", "Rising Rapidly")
                )
            )
            "dfw" -> AirQualityData(
                aqi = 118,
                category = AqiCategory.UNHEALTHY_SENSITIVE,
                dominantPollutant = "Ozone (O3)",
                pm25 = 26.5f,
                pm10 = 62.0f,
                o3 = 78.4f,
                no2 = 32.1f,
                co = 0.6f,
                so2 = 4.2f,
                healthAdvice = "Stagnant pre-storm heat and sunlight has driven elevated ozone. Sensitive groups should avoid strenuous outdoor activity.",
                maskRecommended = true,
                surroundingStations = listOf(
                    SurroundingAqiStation("dfw_dt", "Dallas Downtown Central", 2.4f, "East", 118, AqiCategory.UNHEALTHY_SENSITIVE, "Ozone", "Peak Stagnation"),
                    SurroundingAqiStation("dfw_ftw", "Fort Worth Stockyards", 14.2f, "West", 95, AqiCategory.MODERATE, "PM2.5", "Falling (-6/hr)"),
                    SurroundingAqiStation("dfw_arl", "Arlington Entertainment Dist", 8.0f, "SW", 125, AqiCategory.UNHEALTHY_SENSITIVE, "Ozone", "Rising (+5/hr)"),
                    SurroundingAqiStation("dfw_pln", "Plano Suburban North", 12.6f, "North", 82, AqiCategory.MODERATE, "PM2.5", "Stable")
                )
            )
            "mia" -> AirQualityData(
                aqi = 38,
                category = AqiCategory.GOOD,
                dominantPollutant = "Sea Salt Aerosols",
                pm25 = 6.2f,
                pm10 = 14.0f,
                o3 = 22.1f,
                no2 = 9.8f,
                co = 0.2f,
                so2 = 0.8f,
                healthAdvice = "Tropical trade winds have scoured urban pollutants. Air quality is exceptionally clean.",
                maskRecommended = false,
                surroundingStations = listOf(
                    SurroundingAqiStation("mia_bch", "South Beach Coastal", 3.2f, "East", 28, AqiCategory.GOOD, "Marine Aerosol", "Stable"),
                    SurroundingAqiStation("mia_dt", "Brickell Financial Core", 1.5f, "Center", 42, AqiCategory.GOOD, "PM2.5", "Stable"),
                    SurroundingAqiStation("mia_cor", "Coral Gables Station", 5.8f, "SW", 35, AqiCategory.GOOD, "PM2.5", "Stable"),
                    SurroundingAqiStation("mia_hgh", "Hialeah Northwest", 7.9f, "NW", 54, AqiCategory.MODERATE, "PM10", "Rising (+2/hr)")
                )
            )
            "chi" -> AirQualityData(
                aqi = 78,
                category = AqiCategory.MODERATE,
                dominantPollutant = "PM2.5",
                pm25 = 20.4f,
                pm10 = 42.1f,
                o3 = 45.0f,
                no2 = 24.3f,
                co = 0.5f,
                so2 = 2.4f,
                healthAdvice = "Lake breeze boundary trapping moderate vehicle and industrial emissions along shoreline.",
                maskRecommended = false,
                surroundingStations = listOf(
                    SurroundingAqiStation("chi_loop", "The Loop Downtown", 1.2f, "Center", 82, AqiCategory.MODERATE, "PM2.5", "Stable"),
                    SurroundingAqiStation("chi_nvp", "Navy Pier Lakefront", 2.1f, "East", 52, AqiCategory.MODERATE, "Ozone", "Falling (-4/hr)"),
                    SurroundingAqiStation("chi_lin", "Lincoln Park North", 4.5f, "North", 68, AqiCategory.MODERATE, "PM2.5", "Stable"),
                    SurroundingAqiStation("chi_mid", "Midway Corridor", 9.1f, "SW", 94, AqiCategory.MODERATE, "NO2", "Rising (+6/hr)")
                )
            )
            else -> AirQualityData(
                aqi = 42,
                category = AqiCategory.GOOD,
                dominantPollutant = "PM2.5",
                pm25 = 8.1f,
                pm10 = 18.0f,
                o3 = 24.5f,
                no2 = 12.0f,
                co = 0.2f,
                so2 = 1.0f,
                healthAdvice = "Air quality is pristine. Clean alpine air mass present.",
                maskRecommended = false,
                surroundingStations = listOf(
                    SurroundingAqiStation("den_dt", "Denver Civic Center", 1.4f, "Center", 45, AqiCategory.GOOD, "PM2.5", "Stable"),
                    SurroundingAqiStation("den_bld", "Boulder Foothills", 18.2f, "NW", 26, AqiCategory.GOOD, "Ozone", "Stable"),
                    SurroundingAqiStation("den_aur", "Aurora Plains East", 8.9f, "East", 52, AqiCategory.MODERATE, "PM10", "Rising (+3/hr)")
                )
            )
        }
    }

    fun getAqiEducationalGuides(): List<AqiLevelGuide> {
        return listOf(
            AqiLevelGuide(
                category = AqiCategory.GOOD,
                rangeText = "0 – 50",
                description = "Air quality is considered satisfactory, and air pollution poses little or no risk.",
                generalPopulationImpact = "No health effects expected. Ideal conditions for outdoor recreation, exercise, and open-window ventilation.",
                sensitiveGroupsImpact = "Extremely safe for asthma, COPD, elderly, and pediatric groups.",
                protectiveActions = listOf(
                    "Great day for outdoor workouts and endurance training.",
                    "Keep windows open to naturally ventilate homes before storms arrive."
                )
            ),
            AqiLevelGuide(
                category = AqiCategory.MODERATE,
                rangeText = "51 – 100",
                description = "Air quality is acceptable; however, some pollutants may cause moderate health concern for a very small number of individuals.",
                generalPopulationImpact = "Generally safe for the public. Unusually sensitive individuals may experience minor throat tickles or coughing.",
                sensitiveGroupsImpact = "People with respiratory allergies or cardiovascular disease should monitor prolonged heavy exertion.",
                protectiveActions = listOf(
                    "Unusually sensitive individuals should take more breaks during outdoor activities.",
                    "Close windows if dust or pre-storm winds are actively lofting debris."
                )
            ),
            AqiLevelGuide(
                category = AqiCategory.UNHEALTHY_SENSITIVE,
                rangeText = "101 – 150",
                description = "Members of sensitive groups may experience health effects. The general public is less likely to be affected.",
                generalPopulationImpact = "Most people will not notice symptoms, though prolonged cardio may induce fatigue or eye irritation.",
                sensitiveGroupsImpact = "Significant risk of asthma flare-ups, wheezing, shortness of breath, and chest tightness in children, seniors, and lung/heart patients.",
                protectiveActions = listOf(
                    "Sensitive groups should reduce prolonged or heavy outdoor exertion.",
                    "Carry rescue inhalers if diagnosed with asthma.",
                    "Run HEPA indoor air purifiers and set vehicle AC to recirculate."
                )
            ),
            AqiLevelGuide(
                category = AqiCategory.UNHEALTHY,
                rangeText = "151 – 200",
                description = "Everyone may begin to experience health effects; members of sensitive groups may experience more serious health effects.",
                generalPopulationImpact = "Increased aggravation of heart or lung disease; increased premature mortality risk. Healthy people may experience coughing and shortness of breath.",
                sensitiveGroupsImpact = "Severe asthma attacks, acute bronchitis, increased hospital admissions, accelerated cardiac stress.",
                protectiveActions = listOf(
                    "Everyone should avoid prolonged outdoor exertion; reschedule sports indoors.",
                    "Wear well-fitted N95/KN95 respirators if required to be outdoors.",
                    "Keep all doors, windows, and fireplace dampers tightly closed."
                )
            ),
            AqiLevelGuide(
                category = AqiCategory.VERY_UNHEALTHY,
                rangeText = "201 – 300",
                description = "Health alert: The risk of health effects is increased for everyone in the population.",
                generalPopulationImpact = "Significant impairment of lung function in healthy adults. Widespread respiratory irritation and reduced exercise tolerance.",
                sensitiveGroupsImpact = "Emergency condition: High probability of acute cardio-respiratory failure in high-risk individuals.",
                protectiveActions = listOf(
                    "Avoid all physical activity outdoors. Keep children and pets inside.",
                    "Deploy high-efficiency particulate air (HEPA) cleaners.",
                    "Contact healthcare providers if wheezing or chest tightness occurs."
                )
            ),
            AqiLevelGuide(
                category = AqiCategory.HAZARDOUS,
                rangeText = "301 – 500+",
                description = "Health warning of emergency conditions: The entire population is more likely to be affected.",
                generalPopulationImpact = "Serious risk of respiratory and cardiovascular emergency events across all demographics.",
                sensitiveGroupsImpact = "Catastrophic health hazard requiring immediate shelter in place with air filtration.",
                protectiveActions = listOf(
                    "Remain strictly indoors in a sealed, air-filtered environment.",
                    "Do not burn candles, fry foods, or vacuum indoors to avoid generating indoor particles.",
                    "Use medical-grade P100 or N95 masks if outdoor transit is mandatory."
                )
            )
        )
    }

    fun getStormTrajectories(cityId: String): List<StormTrajectory> {
        return listOf(
            StormTrajectory(
                stormId = "cell_alpha_01",
                name = "Supercell Delta-9 (Tornadic)",
                category = "Right-Moving Rotating Supercell",
                speedMph = 44,
                headingDegrees = 52,
                headingCompass = "NE",
                currentXPercent = 0.32f,
                currentYPercent = 0.68f,
                intensityDbz = 66,
                mesocycloneDetected = true,
                lightningStrikesPerMin = 48,
                waypoints = listOf(
                    TrajectoryWaypoint("+15m", 0.42f, 0.56f, 32f, 72, 85),
                    TrajectoryWaypoint("+30m", 0.54f, 0.44f, 48f, 78, 90),
                    TrajectoryWaypoint("+45m", 0.68f, 0.32f, 64f, 82, 75),
                    TrajectoryWaypoint("+60m", 0.82f, 0.20f, 82f, 65, 50)
                )
            ),
            StormTrajectory(
                stormId = "cell_beta_02",
                name = "Linear Bow Echo Falcon",
                category = "Damaging Wind Squall",
                speedMph = 52,
                headingDegrees = 85,
                headingCompass = "E",
                currentXPercent = 0.18f,
                currentYPercent = 0.35f,
                intensityDbz = 58,
                mesocycloneDetected = false,
                lightningStrikesPerMin = 26,
                waypoints = listOf(
                    TrajectoryWaypoint("+15m", 0.34f, 0.37f, 26f, 60, 40),
                    TrajectoryWaypoint("+30m", 0.50f, 0.39f, 40f, 64, 45),
                    TrajectoryWaypoint("+45m", 0.66f, 0.42f, 54f, 68, 30),
                    TrajectoryWaypoint("+60m", 0.82f, 0.45f, 70f, 55, 20)
                )
            )
        )
    }

    fun getEmergencyShelters(cityId: String): List<EmergencyShelter> {
        return listOf(
            EmergencyShelter(
                id = "sh_01",
                name = "Central Community Storm Shelter",
                address = "1200 N Walker Ave, OKC",
                distanceMiles = 1.4f,
                capacity = 450,
                isUnderground = true,
                isPetFriendly = true,
                hasGenerator = true,
                phone = "(405) 555-0199",
                xPercent = 0.48f,
                yPercent = 0.46f
            ),
            EmergencyShelter(
                id = "sh_02",
                name = "Northwest Civic Safe Room",
                address = "3600 NW 50th St, OKC",
                distanceMiles = 3.8f,
                capacity = 300,
                isUnderground = true,
                isPetFriendly = false,
                hasGenerator = true,
                phone = "(405) 555-0142",
                xPercent = 0.38f,
                yPercent = 0.28f
            ),
            EmergencyShelter(
                id = "sh_03",
                name = "South Metro High School Storm Complex",
                address = "7200 S Pennsylvania Ave",
                distanceMiles = 5.2f,
                capacity = 800,
                isUnderground = false,
                isPetFriendly = true,
                hasGenerator = true,
                phone = "(405) 555-0188",
                xPercent = 0.55f,
                yPercent = 0.72f
            )
        )
    }

    fun getHistoricalStorms(): List<HistoricalStormData> {
        return listOf(
            HistoricalStormData(
                id = "hist_01",
                name = "Great Plains Supercell Outbreak",
                dateString = "May 20, 2024",
                category = "EF-4 Violent Tornado & Giant Hail",
                peakWindGustMph = 112,
                minPressureHpa = 982.4f,
                totalRainfallInches = 4.8f,
                maxHailDiameterInches = 3.5f,
                durationHours = 6,
                summary = "An explosive dryline collision triggered cyclic supercells with severe cyclonic shear. Monitored rapid barometric plunge of 18 hPa in 3 hours preceding initial touchdown.",
                pressureHourlyDrops = listOf(1008f, 1004f, 998f, 990f, 982.4f, 995f),
                rainfallHourlyInches = listOf(0.1f, 0.6f, 1.8f, 1.4f, 0.7f, 0.2f)
            ),
            HistoricalStormData(
                id = "hist_02",
                name = "Midwest Derecho Event",
                dateString = "August 10, 2023",
                category = "Serial Derecho (800-Mile Track)",
                peakWindGustMph = 98,
                minPressureHpa = 992.0f,
                totalRainfallInches = 3.2f,
                maxHailDiameterInches = 1.75f,
                durationHours = 8,
                summary = "Widespread catastrophic straight-line wind corridor with multi-vortex downbursts. Sustained winds over 70 mph across four states.",
                pressureHourlyDrops = listOf(1012f, 1009f, 1003f, 994f, 992f, 1001f),
                rainfallHourlyInches = listOf(0.2f, 1.1f, 1.2f, 0.5f, 0.2f, 0.0f)
            ),
            HistoricalStormData(
                id = "hist_03",
                name = "Gulf Coast Flash Flood Surge",
                dateString = "October 14, 2023",
                category = "Mesoscale Convective Vortex (MCV)",
                peakWindGustMph = 64,
                minPressureHpa = 1001.2f,
                totalRainfallInches = 8.6f,
                maxHailDiameterInches = 1.0f,
                durationHours = 12,
                summary = "Training convective storm bands dumped historic precipitation. Over 8 inches of rain recorded with extensive road submersions.",
                pressureHourlyDrops = listOf(1015f, 1012f, 1008f, 1004f, 1001.2f, 1006f),
                rainfallHourlyInches = listOf(0.4f, 1.6f, 2.8f, 2.2f, 1.1f, 0.5f)
            )
        )
    }

    fun getOfflineMapPacks(): List<OfflineMapPack> {
        return listOf(
            OfflineMapPack(
                id = "map_okc",
                regionName = "Oklahoma & Tornado Alley Zone",
                coverageArea = "350 sq miles (High Resolution Radar + Shelters)",
                sizeMb = 64,
                isDownloaded = true,
                shelterCount = 42
            ),
            OfflineMapPack(
                id = "map_tx",
                regionName = "North Texas & DFW Corridor",
                coverageArea = "420 sq miles (Vector Grid & Topography)",
                sizeMb = 78,
                isDownloaded = true,
                shelterCount = 56
            ),
            OfflineMapPack(
                id = "map_fl",
                regionName = "South Florida & Coastal Surge",
                coverageArea = "280 sq miles (Hurricane Inundation Zones)",
                sizeMb = 52,
                isDownloaded = false,
                shelterCount = 38
            ),
            OfflineMapPack(
                id = "map_mw",
                regionName = "Upper Midwest & Great Lakes",
                coverageArea = "500 sq miles (Gale & Squall Trajectories)",
                sizeMb = 92,
                isDownloaded = false,
                shelterCount = 31
            )
        )
    }

    fun getSurvivalGuides(): List<SurvivalGuide> {
        return listOf(
            SurvivalGuide(
                scenario = "Tornado in a Home or Office",
                immediateAction = "Go immediately to the lowest level (basement or storm shelter). If no basement, take cover in an interior room (bathroom/closet) on the lowest floor.",
                dangerToAvoid = "NEVER open windows to equalize pressure — this is a myth and allows deadly flying glass and wind lift into the building.",
                keyTips = listOf(
                    "Put on bicycle or motorcycle helmets to protect against head trauma from flying debris.",
                    "Wear sturdy shoes in case you need to walk through broken glass and nails.",
                    "Cover yourself with a heavy mattress or thick blankets."
                )
            ),
            SurvivalGuide(
                scenario = "Tornado While Driving a Vehicle",
                immediateAction = "Do NOT attempt to outrun a tornado in dense traffic. If a sturdy shelter is accessible nearby, evacuate the car and seek shelter immediately.",
                dangerToAvoid = "NEVER seek shelter under a highway overpass! Overpasses act as wind tunnels, accelerating air speeds and flying debris.",
                keyTips = listOf(
                    "If caught in open country with no shelter, park the vehicle away from traffic lanes.",
                    "Stay in the car with seatbelt fastened, duck down below the windows, and cover your head.",
                    "If there is a noticeably lower ditch or depression, lie flat face-down and protect the back of your head."
                )
            ),
            SurvivalGuide(
                scenario = "Flash Floods on Roadways",
                immediateAction = "Turn Around, Don't Drown! Just 12 inches of rushing water can carry away a small sedan; 24 inches can sweep away SUVs.",
                dangerToAvoid = "Never drive around barricades or enter flooded intersections where roadbeds may have washed out.",
                keyTips = listOf(
                    "If your vehicle stalls in rapidly rising water, abandon it immediately and seek higher ground.",
                    "Be especially cautious at night when water depth and road hazards are difficult to gauge."
                )
            ),
            SurvivalGuide(
                scenario = "Lightning & Large Hail Outdoors",
                immediateAction = "When Thunder Roars, Go Indoors! Seek shelter in a fully enclosed, substantial building or metal-topped vehicle.",
                dangerToAvoid = "Do not take shelter under isolated trees, metal fences, open pavilions, or near golf carts.",
                keyTips = listOf(
                    "Wait 30 minutes after the last clap of thunder before resuming outdoor activities.",
                    "If hail begins, protect your head immediately with bags, backpacks, or hands."
                )
            )
        )
    }

    fun getPrepChecklist(): List<ChecklistItem> {
        return listOf(
            ChecklistItem("chk_1", "Battery-Powered Weather Radio", "Keep fresh batteries or hand-crank NOAA radio ready.", true),
            ChecklistItem("chk_2", "Water Supply (1 Gallon / Person / Day)", "Store at least 3-day supply of drinking water.", true),
            ChecklistItem("chk_3", "Heavy Work Gloves & Helmets", "Placed in safe room for all family members.", true),
            ChecklistItem("chk_4", "Offline Phone Power Banks", "Fully charged 20,000mAh external battery packs.", true),
            ChecklistItem("chk_5", "First Aid Kit & Prescription Meds", "Sturdy waterproof pouch with 7 days of critical medicine.", false),
            ChecklistItem("chk_6", "Important Documents in Waterproof Bag", "Passports, deeds, insurance policy numbers, emergency contacts.", false)
        )
    }

    val communityReportsFlow: Flow<List<IncidentReportEntity>> = dao.getAllReportsFlow()

    suspend fun seedInitialReportsIfEmpty() {
        if (dao.getReportCount() == 0) {
            val initialReports = listOf(
                IncidentReportEntity(
                    title = "Confirmed Wall Cloud with Rapid Rotation",
                    incidentType = "TORNADO_SIGHTING",
                    severityLevel = "CRITICAL",
                    description = "Spotter team visual contact with rotating wall cloud 4 miles west of Moore. Condensation funnel lowering intermittently.",
                    locationName = "SW 119th St & May Ave",
                    distanceMiles = 3.2f,
                    hailSizeOrFloodDepth = "Funnel Cloud (1.5 mi away)",
                    timestampFormatted = "8 mins ago",
                    reporterName = "StormSpotter #108",
                    isVerifiedSpotter = true,
                    upvoteCount = 47
                ),
                IncidentReportEntity(
                    title = "Tennis-Ball Sized Hail Damage",
                    incidentType = "LARGE_HAIL",
                    severityLevel = "HIGH",
                    description = "Windshields shattered on multiple cars along Interstate 35. Ground covered in hail measuring 2.5 inches in diameter.",
                    locationName = "I-35 Mile Marker 116",
                    distanceMiles = 4.8f,
                    hailSizeOrFloodDepth = "2.5 inch Hail",
                    timestampFormatted = "14 mins ago",
                    reporterName = "Citizen Observer Marcus",
                    isVerifiedSpotter = false,
                    upvoteCount = 29
                ),
                IncidentReportEntity(
                    title = "Downed High-Voltage Powerlines across Road",
                    incidentType = "DOWNED_POWERLINE",
                    severityLevel = "CRITICAL",
                    description = "Severe downburst snapped two utility poles. Live wires arcing across roadway. Emergency dispatch notified.",
                    locationName = "NW 39th Expressway & Meridian",
                    distanceMiles = 2.1f,
                    hailSizeOrFloodDepth = "Road Blocked",
                    timestampFormatted = "22 mins ago",
                    reporterName = "Fire Rescue Auxiliary",
                    isVerifiedSpotter = true,
                    upvoteCount = 56
                ),
                IncidentReportEntity(
                    title = "Creek Overflowing onto Residential Underpass",
                    incidentType = "FLASH_FLOOD",
                    severityLevel = "HIGH",
                    description = "Water rapidly rising, currently 2.5 feet deep over the roadway. Two vehicles stalled out. Avoid intersection.",
                    locationName = "Penn Ave & Deep Fork Creek",
                    distanceMiles = 1.9f,
                    hailSizeOrFloodDepth = "30 inches Water Depth",
                    timestampFormatted = "35 mins ago",
                    reporterName = "Spotter Sarah W.",
                    isVerifiedSpotter = true,
                    upvoteCount = 38
                )
            )
            dao.insertAll(initialReports)
        }
    }

    suspend fun submitReport(report: IncidentReportEntity): Long {
        return dao.insertReport(report)
    }

    suspend fun upvoteReport(reportId: Long) {
        dao.upvoteReport(reportId)
    }
}

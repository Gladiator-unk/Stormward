package com.example.data.model

enum class HazardType(val displayName: String, val iconName: String) {
    TORNADO("Tornado Warning", "tornado"),
    SEVERE_THUNDERSTORM("Severe Thunderstorm", "thunderstorm"),
    FLASH_FLOOD("Flash Flood Warning", "flood"),
    HIGH_WIND("High Wind Advisory", "air"),
    HAIL("Large Hail Warning", "ac_unit"),
    DERECHO("Derecho Threat", "cyclone"),
    HURRICANE("Hurricane Watch", "tsunami"),
    EXTREME_AQI("Toxic Air Quality", "masks")
}

enum class AlertSeverity(val label: String) {
    EXTREME("EXTREME"),
    SEVERE("SEVERE"),
    MODERATE("MODERATE"),
    MINOR("MINOR")
}

enum class PressureTrend(val label: String, val warning: Boolean) {
    FALLING_RAPIDLY("Falling Rapidly (-3.2 hPa/hr)", true),
    FALLING("Falling (-1.1 hPa/hr)", false),
    STEADY("Steady (0.0 hPa/hr)", false),
    RISING("Rising (+1.4 hPa/hr)", false)
}

enum class SevereRiskLevel(val label: String, val colorHex: Long) {
    EXTREME("High / Outbreak Risk (Level 5)", 0xFFFF1744),
    HIGH("Moderate Severe Risk (Level 4)", 0xFFFF5722),
    ENHANCED("Enhanced Storm Risk (Level 3)", 0xFFFF9800),
    SLIGHT("Slight Storm Risk (Level 2)", 0xFFFFEB3B),
    MARGINAL("Marginal Risk (Level 1)", 0xFF4CAF50),
    LOW("Low Threat (Level 0)", 0xFF00C2FF)
}

data class CurrentWeather(
    val locationName: String,
    val stateCode: String,
    val latitude: Double,
    val longitude: Double,
    val tempF: Int,
    val feelsLikeF: Int,
    val condition: String,
    val humidityPercent: Int,
    val windSpeedMph: Int,
    val windDirection: String,
    val windGustMph: Int,
    val pressureHpa: Float,
    val pressureTrend: PressureTrend,
    val dewPointF: Int,
    val uvIndex: Int,
    val visibilityMiles: Float,
    val severeRiskLevel: SevereRiskLevel,
    val lightningStrikesNearby: Int,
    val radarReflectivityDbz: Int
)

data class SevereAlert(
    val id: String,
    val hazardType: HazardType,
    val severity: AlertSeverity,
    val title: String,
    val headline: String,
    val issuedTime: String,
    val expiresTime: String,
    val description: String,
    val actionRecommended: String,
    val affectedZones: List<String>,
    val maxWindGustMph: Int,
    val hailSizeInches: Float,
    val distanceMiles: Float,
    val bearing: String
)

data class HourlyForecast(
    val timeLabel: String,
    val tempF: Int,
    val precipProbability: Int,
    val condition: String,
    val windMph: Int,
    val isSeverePotential: Boolean
)

data class DailyForecast(
    val dayLabel: String,
    val highTempF: Int,
    val lowTempF: Int,
    val precipProbability: Int,
    val condition: String,
    val severeRisk: SevereRiskLevel
)

enum class AqiCategory(val label: String, val colorHex: Long, val advisory: String) {
    GOOD("Good (0-50)", 0xFF10B981, "Air quality is satisfactory; storm passage has cleared particulate matter."),
    MODERATE("Moderate (51-100)", 0xFFFACC15, "Acceptable air quality; sensitive individuals should monitor respiration."),
    UNHEALTHY_SENSITIVE("Unhealthy for Sensitive Groups (101-150)", 0xFFF97316, "Members of sensitive groups may experience health effects. Limit prolonged outdoor exertion."),
    UNHEALTHY("Unhealthy (151-200)", 0xFFEF4444, "Everyone may begin to experience health effects. Active outdoor activities should be curtailed."),
    VERY_UNHEALTHY("Very Unhealthy (201-300)", 0xFFA855F7, "Health alert: The risk of health effects is increased for everyone. Stay indoors with air filtration."),
    HAZARDOUS("Hazardous (301-500)", 0xFF881337, "Health warning of emergency conditions. Severe storm downbursts lofting dust & debris.")
}

data class AirQualityData(
    val aqi: Int,
    val category: AqiCategory,
    val dominantPollutant: String,
    val pm25: Float,
    val pm10: Float,
    val o3: Float,
    val no2: Float,
    val co: Float,
    val so2: Float,
    val healthAdvice: String,
    val maskRecommended: Boolean,
    val surroundingStations: List<SurroundingAqiStation> = emptyList()
)

data class SurroundingAqiStation(
    val id: String,
    val stationName: String,
    val distanceMiles: Float,
    val direction: String,
    val aqi: Int,
    val category: AqiCategory,
    val dominantPollutant: String,
    val trend: String
)

data class AqiLevelGuide(
    val category: AqiCategory,
    val rangeText: String,
    val description: String,
    val generalPopulationImpact: String,
    val sensitiveGroupsImpact: String,
    val protectiveActions: List<String>
)

data class TrajectoryWaypoint(
    val timeLabel: String, // e.g., "+15 min", "+30 min", "+45 min", "+60 min"
    val xPercent: Float, // relative 0..1 coordinates on interactive radar
    val yPercent: Float,
    val coneRadiusDp: Float,
    val estimatedWindMph: Int,
    val hailRiskPercent: Int
)

data class StormTrajectory(
    val stormId: String,
    val name: String,
    val category: String, // e.g. "Rotating Supercell", "Linear Bow Echo", "Tornadic Vortex"
    val speedMph: Int,
    val headingDegrees: Int,
    val headingCompass: String,
    val currentXPercent: Float,
    val currentYPercent: Float,
    val intensityDbz: Int,
    val mesocycloneDetected: Boolean,
    val lightningStrikesPerMin: Int,
    val waypoints: List<TrajectoryWaypoint>
)

data class HistoricalStormData(
    val id: String,
    val name: String,
    val dateString: String,
    val category: String,
    val peakWindGustMph: Int,
    val minPressureHpa: Float,
    val totalRainfallInches: Float,
    val maxHailDiameterInches: Float,
    val durationHours: Int,
    val summary: String,
    val pressureHourlyDrops: List<Float>, // 6 data points showing hPa drop
    val rainfallHourlyInches: List<Float>
)

data class OfflineMapPack(
    val id: String,
    val regionName: String,
    val coverageArea: String,
    val sizeMb: Int,
    val isDownloaded: Boolean,
    val shelterCount: Int,
    val downloadProgress: Float = 1.0f
)

data class EmergencyShelter(
    val id: String,
    val name: String,
    val address: String,
    val distanceMiles: Float,
    val capacity: Int,
    val isUnderground: Boolean,
    val isPetFriendly: Boolean,
    val hasGenerator: Boolean,
    val phone: String,
    val xPercent: Float,
    val yPercent: Float
)

data class NotificationSettings(
    val severeThunderstormAlerts: Boolean = true,
    val tornadoWarnings: Boolean = true,
    val flashFloodAlerts: Boolean = true,
    val highWindAlerts: Boolean = true,
    val hailAlerts: Boolean = true,
    val extremeAqiAlerts: Boolean = true,
    val soundEnabled: Boolean = true,
    val emergencySirenMode: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val minimumLeadTimeMinutes: Int = 30, // 15, 30, 45, 60
    val overrideDoNotDisturb: Boolean = true
)

data class SurvivalGuide(
    val scenario: String,
    val immediateAction: String,
    val dangerToAvoid: String,
    val keyTips: List<String>
)

data class ChecklistItem(
    val id: String,
    val title: String,
    val description: String,
    val isChecked: Boolean = false
)

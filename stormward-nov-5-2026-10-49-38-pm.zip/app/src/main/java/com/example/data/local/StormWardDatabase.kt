package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [IncidentReportEntity::class], version = 1, exportSchema = false)
abstract class StormWardDatabase : RoomDatabase() {
    abstract fun incidentReportDao(): IncidentReportDao

    companion object {
        @Volatile
        private var INSTANCE: StormWardDatabase? = null

        fun getInstance(context: Context): StormWardDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    StormWardDatabase::class.java,
                    "stormward_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}

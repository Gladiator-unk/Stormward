package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface IncidentReportDao {
    @Query("SELECT * FROM incident_reports ORDER BY reportedEpochMs DESC")
    fun getAllReportsFlow(): Flow<List<IncidentReportEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: IncidentReportEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(reports: List<IncidentReportEntity>)

    @Update
    suspend fun updateReport(report: IncidentReportEntity)

    @Query("UPDATE incident_reports SET upvoteCount = upvoteCount + 1, hasUserUpvoted = 1 WHERE id = :reportId AND hasUserUpvoted = 0")
    suspend fun upvoteReport(reportId: Long)

    @Query("SELECT COUNT(*) FROM incident_reports")
    suspend fun getReportCount(): Int

    @Query("DELETE FROM incident_reports WHERE id = :reportId")
    suspend fun deleteReport(reportId: Long)
}

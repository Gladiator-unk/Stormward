package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.StormWardViewModel
import com.example.util.NotificationHelper

class MainActivity : ComponentActivity() {

    private val viewModel: StormWardViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Notification Channels
        NotificationHelper.createNotificationChannel(this)

        setContent {
            StormWardTheme {
                val context = LocalContext.current
                var currentTab by remember { mutableIntStateOf(1) } // Default to Live Monitor (1)
                var showCityMenu by remember { mutableStateOf(false) }
                var showCreditsDialog by remember { mutableStateOf(false) }

                val selectedCityId by viewModel.selectedCityId.collectAsState()
                val currentWeather by viewModel.currentWeather.collectAsState()
                val activeAlerts by viewModel.activeAlerts.collectAsState()
                val availableCities = viewModel.availableCities

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(StormDarkBg),
                    topBar = {
                        TopAppBar(
                            title = {
                                Column(
                                    modifier = Modifier.clickable { showCreditsDialog = true }
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "StormWard",
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Black,
                                            color = StormCyanPrimary
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(SevereDanger)
                                        )
                                    }
                                    Text(
                                        text = "made by Gladiator.unk aka Shaik UzairUzair",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = StormCyanPrimary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            },
                            actions = {
                                // Monitored City Switcher Chip
                                Box {
                                    Surface(
                                        color = StormSurfaceVariant,
                                        shape = RoundedCornerShape(20.dp),
                                        border = BorderStroke(1.dp, StormBorder),
                                        modifier = Modifier
                                            .clickable { showCityMenu = true }
                                            .testTag("city_selector_chip")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                Icons.Default.LocationOn,
                                                contentDescription = null,
                                                tint = StormCyanPrimary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "${currentWeather.locationName}, ${currentWeather.stateCode}",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = TextPrimary,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Icon(
                                                Icons.Default.ArrowDropDown,
                                                contentDescription = null,
                                                tint = TextSecondary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }

                                    DropdownMenu(
                                        expanded = showCityMenu,
                                        onDismissRequest = { showCityMenu = false },
                                        modifier = Modifier.background(StormSurface)
                                    ) {
                                        availableCities.forEach { city ->
                                            DropdownMenuItem(
                                                text = {
                                                    Column {
                                                        Text(
                                                            text = "${city.name}, ${city.state}",
                                                            color = if (city.id == selectedCityId) StormCyanPrimary else TextPrimary,
                                                            fontWeight = if (city.id == selectedCityId) FontWeight.Bold else FontWeight.Normal
                                                        )
                                                        Text(
                                                            text = city.defaultRisk.label,
                                                            fontSize = 10.sp,
                                                            color = Color(city.defaultRisk.colorHex)
                                                        )
                                                    }
                                                },
                                                leadingIcon = {
                                                    Icon(
                                                        Icons.Default.Place,
                                                        contentDescription = null,
                                                        tint = if (city.id == selectedCityId) StormCyanPrimary else TextTertiary
                                                    )
                                                },
                                                onClick = {
                                                    viewModel.selectCity(city.id)
                                                    showCityMenu = false
                                                }
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.width(4.dp))

                                // Credits Button
                                IconButton(
                                    onClick = { showCreditsDialog = true },
                                    modifier = Modifier.testTag("top_credits_button")
                                ) {
                                    Icon(
                                        Icons.Default.Info,
                                        contentDescription = "Credits",
                                        tint = StormCyanPrimary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                // Quick Emergency Alert Test Button
                                IconButton(
                                    onClick = { viewModel.simulatePushAlert(context) },
                                    modifier = Modifier.testTag("top_test_alert_button")
                                ) {
                                    Badge(containerColor = SevereDanger) {
                                        Text("${activeAlerts.size}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = StormSurface,
                                titleContentColor = TextPrimary
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = StormSurface,
                            tonalElevation = 8.dp
                        ) {
                            NavigationBarItem(
                                selected = currentTab == 0,
                                onClick = { currentTab = 0 },
                                icon = {
                                    Icon(
                                        Icons.Default.Radar,
                                        contentDescription = "Radar & Trajectory Tracks"
                                    )
                                },
                                label = { Text("Radar", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = StormCyanPrimary,
                                    selectedTextColor = StormCyanPrimary,
                                    indicatorColor = StormCyanContainer,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("nav_item_radar")
                            )

                            NavigationBarItem(
                                selected = currentTab == 1,
                                onClick = { currentTab = 1 },
                                icon = {
                                    Icon(
                                        Icons.Default.Speed,
                                        contentDescription = "Live Monitor"
                                    )
                                },
                                label = { Text("Monitor", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = StormCyanPrimary,
                                    selectedTextColor = StormCyanPrimary,
                                    indicatorColor = StormCyanContainer,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("nav_item_monitor")
                            )

                            NavigationBarItem(
                                selected = currentTab == 2,
                                onClick = { currentTab = 2 },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (activeAlerts.isNotEmpty()) {
                                                Badge(containerColor = SevereDanger) {
                                                    Text("${activeAlerts.size}", color = Color.White)
                                                }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            Icons.Default.NotificationsActive,
                                            contentDescription = "Alerts & Push"
                                        )
                                    }
                                },
                                label = { Text("Alerts", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = SevereAmber,
                                    selectedTextColor = SevereAmber,
                                    indicatorColor = SevereAmberContainer,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("nav_item_alerts")
                            )

                            NavigationBarItem(
                                selected = currentTab == 3,
                                onClick = { currentTab = 3 },
                                icon = {
                                    Icon(
                                        Icons.Default.Timeline,
                                        contentDescription = "Historical Analytics"
                                    )
                                },
                                label = { Text("History", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = StormCyanPrimary,
                                    selectedTextColor = StormCyanPrimary,
                                    indicatorColor = StormCyanContainer,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("nav_item_history")
                            )

                            NavigationBarItem(
                                selected = currentTab == 4,
                                onClick = { currentTab = 4 },
                                icon = {
                                    Icon(
                                        Icons.Default.People,
                                        contentDescription = "Community & Offline"
                                    )
                                },
                                label = { Text("Community", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = StormCyanPrimary,
                                    selectedTextColor = StormCyanPrimary,
                                    indicatorColor = StormCyanContainer,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("nav_item_community")
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentTab) {
                            0 -> RadarMapScreen(viewModel = viewModel)
                            1 -> MonitorScreen(
                                viewModel = viewModel,
                                onNavigateToRadar = { currentTab = 0 }
                            )
                            2 -> AlertsScreen(viewModel = viewModel)
                            3 -> HistoryAnalyticsScreen(viewModel = viewModel)
                            4 -> CommunityOfflineScreen(viewModel = viewModel)
                        }
                    }

                    if (showCreditsDialog) {
                        ModalBottomSheet(
                            onDismissRequest = { showCreditsDialog = false },
                            containerColor = StormSurface,
                            dragHandle = { BottomSheetDefaults.DragHandle(color = StormBorder) }
                        ) {
                            CreditsScreen(onDismiss = { showCreditsDialog = false })
                        }
                    }
                }
            }
        }
    }
}

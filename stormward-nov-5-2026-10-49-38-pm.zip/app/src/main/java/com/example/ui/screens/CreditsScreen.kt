package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun CreditsScreen(
    onDismiss: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(StormDarkBg)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Dismiss button if shown as sub-screen or modal
        if (onDismiss != null) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(StormSurfaceVariant)
                            .testTag("credits_close_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close Credits", tint = TextPrimary)
                    }
                }
            }
        }

        // Hero Avatar & Name Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.5.dp, StormCyanPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("credits_hero_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Pulsing Avatar Ring
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(StormCyanPrimary, StormCyanContainer, StormDarkBg)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(76.dp)
                                .clip(CircleShape)
                                .background(StormSurface),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = StormCyanPrimary,
                                modifier = Modifier.size(42.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "StormWard",
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.ExtraBold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // EXACT USER SPECIFIED ATTRIBUTION STRING
                    Surface(
                        color = StormCyanContainer,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, StormCyanPrimary.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = "made by Gladiator.unk aka Shaik UzairUzair",
                            style = MaterialTheme.typography.titleMedium,
                            color = StormCyanPrimary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                                .testTag("credits_author_tag")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Lead Meteorologist & Radar Software Architect",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SevereAmber,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // App Purpose & Engineering Mission
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, StormBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Stars, contentDescription = null, tint = SevereAmber)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "About the Project",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "StormWard is an advanced, resilient meteorological monitor designed to safeguard communities against severe atmospheric events. Built from the ground up to detect violent cyclic supercells, rapid barometric plunges, flash floods, and toxic air quality conditions.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Core pillars chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CreditBadgeItem("🌪️ Tornado Warning Radar", modifier = Modifier.weight(1f))
                        CreditBadgeItem("💨 Trajectory Forecasts", modifier = Modifier.weight(1f))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CreditBadgeItem("🍃 Regional AQI Index", modifier = Modifier.weight(1f))
                        CreditBadgeItem("📱 Zero-Cell Offline Maps", modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // Technical Specifications & System Stack
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, StormBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Technology Stack & Core Engine",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    CreditSpecRow("Engineered By", "Gladiator.unk aka Shaik UzairUzair")
                    CreditSpecRow("Framework", "Kotlin • Jetpack Compose • Material 3")
                    CreditSpecRow("Database", "Room Architecture (Offline Decentralized)")
                    CreditSpecRow("Radar Render", "High-Performance Canvas Vector Doppler")
                    CreditSpecRow("Telemetry", "Live Multi-Station AQI + NEXRAD dBZ")
                    CreditSpecRow("Version", "1.0.4 Production Edition")
                }
            }
        }

        // Special Thanks & Community Network
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurfaceVariant),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, StormBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Community Spotters & First Responders",
                        style = MaterialTheme.typography.titleSmall,
                        color = StormEmerald,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Special thanks to all volunteer storm spotters, SKYWARN dispatchers, and local emergency response teams who contribute real-time incident reports to protect lives.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // Footer copyright / signature
        item {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 12.dp)
            ) {
                Text(
                    text = "StormWard • made by Gladiator.unk aka Shaik UzairUzair",
                    style = MaterialTheme.typography.labelMedium,
                    color = StormCyanPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "All Rights Reserved • Life-Safety Compliant",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextTertiary
                )
            }
        }
    }
}

@Composable
fun CreditBadgeItem(text: String, modifier: Modifier = Modifier) {
    Surface(
        color = StormSurfaceVariant,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, StormBorder),
        modifier = modifier
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = TextPrimary,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        )
    }
}

@Composable
fun CreditSpecRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextTertiary)
        Text(text = value, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Bold)
    }
}

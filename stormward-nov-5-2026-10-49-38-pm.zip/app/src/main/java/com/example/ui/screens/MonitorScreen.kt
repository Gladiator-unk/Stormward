package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AlertSeverity
import com.example.data.model.AqiCategory
import com.example.data.model.PressureTrend
import com.example.data.model.SevereAlert
import com.example.ui.components.AqiCircularGauge
import com.example.ui.components.AqiDetailBottomSheet
import com.example.ui.components.SurroundingAqiStationCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.StormWardViewModel
import com.example.util.ShareHelper

@Composable
fun MonitorScreen(
    viewModel: StormWardViewModel,
    onNavigateToRadar: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentWeather by viewModel.currentWeather.collectAsState()
    val activeAlerts by viewModel.activeAlerts.collectAsState()
    val hourlyForecast by viewModel.hourlyForecast.collectAsState()
    val dailyForecast by viewModel.dailyForecast.collectAsState()
    val aqiData by viewModel.airQuality.collectAsState()
    val aqiGuides = viewModel.aqiEducationalGuides

    var showAqiSheet by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(StormDarkBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Creator Attribution & Emergency Status Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                border = BorderStroke(1.dp, StormCyanPrimary.copy(alpha = 0.35f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(StormCyanContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Security,
                                contentDescription = null,
                                tint = StormCyanPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "StormWard Core Meteorological Grid",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "made by Gladiator.unk aka Shaik UzairUzair",
                                style = MaterialTheme.typography.labelSmall,
                                color = StormCyanPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    Badge(containerColor = SevereDanger) {
                        Text("${activeAlerts.size} ALERTS", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 2. Severe Risk Meter & Hero Weather Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, Color(currentWeather.severeRiskLevel.colorHex).copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    // Risk level badge
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = Color(currentWeather.severeRiskLevel.colorHex).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(currentWeather.severeRiskLevel.colorHex))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = Color(currentWeather.severeRiskLevel.colorHex),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = currentWeather.severeRiskLevel.label.uppercase(),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color(currentWeather.severeRiskLevel.colorHex),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Tap to view radar shortcut
                        TextButton(onClick = onNavigateToRadar) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Open Radar", color = StormCyanPrimary, fontSize = 13.sp)
                                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = StormCyanPrimary, modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Temperature & Condition
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = "${currentWeather.tempF}°",
                                style = MaterialTheme.typography.displayMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "Feels like ${currentWeather.feelsLikeF}° • Dew Pt ${currentWeather.dewPointF}°",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = currentWeather.condition,
                                style = MaterialTheme.typography.titleMedium,
                                color = SevereAmber,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Reflectivity: ${currentWeather.radarReflectivityDbz} dBZ",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextTertiary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))
                    HorizontalDivider(color = StormBorder)
                    Spacer(modifier = Modifier.height(14.dp))

                    // Rapid Barometric Pressure Drop Watch (Tornado / Severe Storm Signature)
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (currentWeather.pressureTrend.warning) SevereDangerContainer.copy(alpha = 0.5f) else StormSurfaceVariant
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (currentWeather.pressureTrend.warning) SevereDanger else StormBorder
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (currentWeather.pressureTrend.warning) Icons.Default.TrendingDown else Icons.Default.Speed,
                                contentDescription = null,
                                tint = if (currentWeather.pressureTrend.warning) SevereDanger else StormCyanPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Barometric Pressure: ${currentWeather.pressureHpa} hPa",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (currentWeather.pressureTrend.warning) {
                                        "CRITICAL: Rapid Barometric Drop (-3.2 hPa/hr) indicates explosive cyclogenesis!"
                                    } else {
                                        currentWeather.pressureTrend.label
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (currentWeather.pressureTrend.warning) SevereDanger else TextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Key Meteorological Metrics Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        WeatherMetricItem(
                            label = "WIND",
                            value = "${currentWeather.windSpeedMph} mph",
                            subValue = "Gusts ${currentWeather.windGustMph} mph",
                            icon = Icons.Default.Air
                        )
                        WeatherMetricItem(
                            label = "HUMIDITY",
                            value = "${currentWeather.humidityPercent}%",
                            subValue = "High Moisture",
                            icon = Icons.Default.WaterDrop
                        )
                        WeatherMetricItem(
                            label = "LIGHTNING",
                            value = "${currentWeather.lightningStrikesNearby}",
                            subValue = "Strikes/hr",
                            icon = Icons.Default.Bolt,
                            valueColor = SevereAmber
                        )
                        WeatherMetricItem(
                            label = "VISIBILITY",
                            value = "${currentWeather.visibilityMiles} mi",
                            subValue = "Reduced",
                            icon = Icons.Default.Visibility
                        )
                    }
                }
            }
        }

        // 3. Active Severe Storm Alerts
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Active Severe Storm Alerts",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${activeAlerts.size} in your area",
                        style = MaterialTheme.typography.labelMedium,
                        color = SevereDanger,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                activeAlerts.forEach { alert ->
                    SevereAlertCard(
                        alert = alert,
                        onShare = { ShareHelper.shareSevereAlert(context, alert) },
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }
            }
        }

        // 4. Air Quality Index (AQI) Real-time Tracking & Surrounding Areas
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(aqiData.category.colorHex).copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Masks, contentDescription = null, tint = Color(aqiData.category.colorHex))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Air Quality Index (AQI)",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            color = Color(aqiData.category.colorHex).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "AQI ${aqiData.aqi}",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color(aqiData.category.colorHex),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Gauge + Status & Dominant Pollutant Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AqiCircularGauge(
                            aqi = aqiData.aqi,
                            category = aqiData.category,
                            modifier = Modifier.padding(end = 16.dp)
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = aqiData.category.label,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color(aqiData.category.colorHex),
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Primary: ${aqiData.dominantPollutant}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = aqiData.healthAdvice,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                                lineHeight = 14.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Pollutant Breakdown Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        PollutantChip("PM2.5", "${aqiData.pm25} µg/m³")
                        PollutantChip("PM10", "${aqiData.pm10} µg/m³")
                        PollutantChip("Ozone (O3)", "${aqiData.o3} ppb")
                        PollutantChip("NO2", "${aqiData.no2} ppb")
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Surrounding Areas Snapshot Banner
                    if (aqiData.surroundingStations.isNotEmpty()) {
                        Surface(
                            color = StormSurfaceVariant,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.NearMe, contentDescription = null, tint = StormCyanPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${aqiData.surroundingStations.size} Surrounding Stations Monitored",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Text(
                                    text = "Range: ${aqiData.surroundingStations.minOf { it.aqi }}–${aqiData.surroundingStations.maxOf { it.aqi }} AQI",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SevereAmber,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Primary Button to open Surrounding Stations & Health Guide BottomSheet
                    OutlinedButton(
                        onClick = { showAqiSheet = true },
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = StormCyanContainer.copy(alpha = 0.5f),
                            contentColor = StormCyanPrimary
                        ),
                        border = BorderStroke(1.dp, StormCyanPrimary.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("open_aqi_details_button")
                    ) {
                        Icon(Icons.Default.Explore, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("View Surrounding Areas & Health Guide", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // 5. Hourly Storm Threat Timeline
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, StormBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Hourly Severe Storm Threat",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(hourlyForecast) { item ->
                            HourlyThreatCard(item)
                        }
                    }
                }
            }
        }

        // 6. 7-Day Severe Outlook
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, StormBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "7-Day Severe Weather Outlook",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    dailyForecast.forEach { day ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = day.dayLabel,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.width(64.dp)
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.WaterDrop, contentDescription = null, tint = StormCyanPrimary, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${day.precipProbability}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StormCyanPrimary
                                )
                            }
                            Text(
                                text = day.condition,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                modifier = Modifier.weight(1f).padding(horizontal = 12.dp)
                            )
                            Surface(
                                color = Color(day.severeRisk.colorHex).copy(alpha = 0.2f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = day.severeRisk.label.take(8),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(day.severeRisk.colorHex),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "${day.highTempF}° / ${day.lowTempF}°",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAqiSheet) {
        AqiDetailBottomSheet(
            airQualityData = aqiData,
            guides = aqiGuides,
            onDismiss = { showAqiSheet = false }
        )
    }
}

@Composable
fun WeatherMetricItem(
    label: String,
    value: String,
    subValue: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    valueColor: Color = TextPrimary
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = null, tint = StormCyanPrimary, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextTertiary, fontSize = 10.sp)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, color = valueColor, fontWeight = FontWeight.Bold)
        Text(text = subValue, style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 9.sp)
    }
}

@Composable
fun PollutantChip(name: String, value: String) {
    Surface(
        color = StormSurfaceVariant,
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = name, style = MaterialTheme.typography.labelSmall, color = TextTertiary, fontSize = 10.sp)
            Text(text = value, style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SevereAlertCard(
    alert: SevereAlert,
    onShare: () -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = when (alert.severity) {
                AlertSeverity.EXTREME -> SevereDangerContainer.copy(alpha = 0.5f)
                AlertSeverity.SEVERE -> SevereAmberContainer.copy(alpha = 0.5f)
                else -> StormSurfaceVariant
            }
        ),
        border = BorderStroke(
            1.dp,
            when (alert.severity) {
                AlertSeverity.EXTREME -> SevereDanger
                AlertSeverity.SEVERE -> SevereAmber
                else -> StormBorder
            }
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .testTag("severe_alert_card_${alert.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = when (alert.severity) {
                            AlertSeverity.EXTREME -> SevereDanger
                            AlertSeverity.SEVERE -> SevereAmber
                            else -> StormCyanPrimary
                        },
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = alert.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(
                    onClick = onShare,
                    modifier = Modifier.size(32.dp).testTag("share_alert_button_${alert.id}")
                ) {
                    Icon(
                        Icons.Default.Share,
                        contentDescription = "Share Alert",
                        tint = StormCyanPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = alert.headline,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "💨 Max Winds: ${alert.maxWindGustMph} mph",
                    style = MaterialTheme.typography.labelSmall,
                    color = SevereAmber
                )
                Text(
                    text = "🧊 Hail: ${alert.hailSizeInches}\"",
                    style = MaterialTheme.typography.labelSmall,
                    color = StormCyanPrimary
                )
                Text(
                    text = "Expires: ${alert.expiresTime}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextTertiary
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    HorizontalDivider(color = StormBorder)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Detailed Meteorological Overview:",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = alert.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = SevereDanger.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "🛡️ RECOMMENDED ACTION:",
                                style = MaterialTheme.typography.labelSmall,
                                color = SevereDanger,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = alert.actionRecommended,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Impact Zones: ${alert.affectedZones.joinToString(", ")}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
fun HourlyThreatCard(item: com.example.data.model.HourlyForecast) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (item.isSeverePotential) SevereDangerContainer.copy(alpha = 0.4f) else StormSurfaceVariant
        ),
        border = BorderStroke(
            1.dp,
            if (item.isSeverePotential) SevereDanger else StormBorder
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.width(82.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(item.timeLabel, style = MaterialTheme.typography.labelSmall, color = TextTertiary)
            Spacer(modifier = Modifier.height(6.dp))
            Icon(
                imageVector = if (item.isSeverePotential) Icons.Default.Thunderstorm else Icons.Default.Cloud,
                contentDescription = null,
                tint = if (item.isSeverePotential) SevereDanger else StormCyanPrimary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text("${item.tempF}°", style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text("${item.precipProbability}%", style = MaterialTheme.typography.labelSmall, color = StormCyanPrimary)
            Text("${item.windMph}mph", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 9.sp)
        }
    }
}

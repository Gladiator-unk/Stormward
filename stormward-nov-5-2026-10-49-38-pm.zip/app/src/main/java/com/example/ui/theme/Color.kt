package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Atmospheric Dark Storm Palette
val StormDarkBg = Color(0xFF070D19)
val StormSurface = Color(0xFF0F1A2C)
val StormSurfaceVariant = Color(0xFF18263E)
val StormBorder = Color(0xFF243B5E)

// Vibrant Accent Colors
val StormCyanPrimary = Color(0xFF00D2FF)
val StormCyanContainer = Color(0xFF00384D)
val StormOnCyan = Color(0xFF001B26)

val SevereAmber = Color(0xFFFFB300)
val SevereAmberContainer = Color(0xFF4D3300)

val SevereDanger = Color(0xFFFF3B30)
val SevereDangerContainer = Color(0xFF4D0B07)

val StormPurple = Color(0xFFB388FF)
val StormEmerald = Color(0xFF00E676)

// Text Colors
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

// Radar Reflectivity dBZ Colors
val RadarGreen = Color(0xFF10B981)
val RadarYellow = Color(0xFFFACC15)
val RadarOrange = Color(0xFFF97316)
val RadarRed = Color(0xFFEF4444)
val RadarPurple = Color(0xFFA855F7)
val RadarPink = Color(0xFFF43F5E)

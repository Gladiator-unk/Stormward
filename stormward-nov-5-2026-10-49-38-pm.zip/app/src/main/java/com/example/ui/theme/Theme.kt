package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = StormCyanPrimary,
    onPrimary = StormOnCyan,
    primaryContainer = StormCyanContainer,
    onPrimaryContainer = StormCyanPrimary,
    secondary = SevereAmber,
    onSecondary = Color.Black,
    secondaryContainer = SevereAmberContainer,
    onSecondaryContainer = SevereAmber,
    tertiary = SevereDanger,
    onTertiary = Color.White,
    tertiaryContainer = SevereDangerContainer,
    onTertiaryContainer = Color(0xFFFFB4AB),
    background = StormDarkBg,
    onBackground = TextPrimary,
    surface = StormSurface,
    onSurface = TextPrimary,
    surfaceVariant = StormSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = StormBorder
)

private val LightColorScheme = darkColorScheme( // Storm apps look much clearer in dark atmospheric mode
    primary = StormCyanPrimary,
    onPrimary = StormOnCyan,
    primaryContainer = StormCyanContainer,
    secondary = SevereAmber,
    background = StormDarkBg,
    surface = StormSurface,
    surfaceVariant = StormSurfaceVariant,
    onSurface = TextPrimary,
    outline = StormBorder
)

@Composable
fun StormWardTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = DarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = StormDarkBg.toArgb()
                window.navigationBarColor = StormDarkBg.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

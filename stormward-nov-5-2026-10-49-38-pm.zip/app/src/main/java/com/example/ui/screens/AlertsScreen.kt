package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NotificationSettings
import com.example.ui.theme.*
import com.example.ui.viewmodel.StormWardViewModel
import com.example.util.ShareHelper

@Composable
fun AlertsScreen(
    viewModel: StormWardViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activeAlerts by viewModel.activeAlerts.collectAsState()
    val notificationSettings by viewModel.notificationSettings.collectAsState()
    val testAlertStatus by viewModel.testAlertStatus.collectAsState()

    // Permission launcher for Android 13+ POST_NOTIFICATIONS
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.simulatePushAlert(context)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(StormDarkBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Status & Test Alert Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, StormCyanPrimary.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(StormCyanContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.NotificationsActive,
                                contentDescription = null,
                                tint = StormCyanPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Push Notification Dispatcher",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "High-priority emergency alerts triggered by real-time Doppler radar",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                viewModel.simulatePushAlert(context)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SevereDanger,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("test_push_alert_button")
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Simulate Live Emergency Push Alert", fontWeight = FontWeight.Bold)
                    }

                    AnimatedVisibility(visible = testAlertStatus != null) {
                        Surface(
                            color = StormEmerald.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp)
                        ) {
                            Text(
                                text = testAlertStatus ?: "",
                                style = MaterialTheme.typography.labelSmall,
                                color = StormEmerald,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }
        }

        // Active Alerts List
        item {
            Text(
                text = "Active Alerts in Monitored Sector (${activeAlerts.size})",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
        }

        items(activeAlerts.size) { idx ->
            val alert = activeAlerts[idx]
            SevereAlertCard(
                alert = alert,
                onShare = { ShareHelper.shareSevereAlert(context, alert) }
            )
        }

        // Customizable Push Notification Preferences
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, StormBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Customizable Alert Thresholds",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Filter which severe hazards wake your device and sound sirens",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    NotificationToggleRow(
                        title = "Tornado Warnings (Rotation / Debris)",
                        subtitle = "Instant siren tone and screen wake",
                        checked = notificationSettings.tornadoWarnings,
                        onCheckedChange = {
                            viewModel.updateNotificationSettings(notificationSettings.copy(tornadoWarnings = it))
                        },
                        tag = "toggle_tornado_warning"
                    )

                    NotificationToggleRow(
                        title = "Severe Thunderstorms (>60 mph)",
                        subtitle = "Straight-line winds and microbursts",
                        checked = notificationSettings.severeThunderstormAlerts,
                        onCheckedChange = {
                            viewModel.updateNotificationSettings(notificationSettings.copy(severeThunderstormAlerts = it))
                        },
                        tag = "toggle_thunderstorm_alerts"
                    )

                    NotificationToggleRow(
                        title = "Flash Flood Emergencies",
                        subtitle = "Rapid road washouts and river surges",
                        checked = notificationSettings.flashFloodAlerts,
                        onCheckedChange = {
                            viewModel.updateNotificationSettings(notificationSettings.copy(flashFloodAlerts = it))
                        },
                        tag = "toggle_flood_alerts"
                    )

                    NotificationToggleRow(
                        title = "Destructive Large Hail (>1.5\")",
                        subtitle = "Vehicle and roof protection notifications",
                        checked = notificationSettings.hailAlerts,
                        onCheckedChange = {
                            viewModel.updateNotificationSettings(notificationSettings.copy(hailAlerts = it))
                        },
                        tag = "toggle_hail_alerts"
                    )

                    NotificationToggleRow(
                        title = "Extreme AQI Pollution (>150)",
                        subtitle = "Toxic wildfire smoke and storm dust lofts",
                        checked = notificationSettings.extremeAqiAlerts,
                        onCheckedChange = {
                            viewModel.updateNotificationSettings(notificationSettings.copy(extremeAqiAlerts = it))
                        },
                        tag = "toggle_aqi_alerts"
                    )

                    HorizontalDivider(color = StormBorder, modifier = Modifier.padding(vertical = 12.dp))

                    Text(
                        text = "Sound & Haptic Preferences",
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    NotificationToggleRow(
                        title = "Emergency Siren Audio",
                        subtitle = "Loud dual-tone alert sound",
                        checked = notificationSettings.soundEnabled,
                        onCheckedChange = {
                            viewModel.updateNotificationSettings(notificationSettings.copy(soundEnabled = it))
                        },
                        tag = "toggle_sound"
                    )

                    NotificationToggleRow(
                        title = "Severe Haptic Vibration",
                        subtitle = "Repeated pulsing pattern for sensory alerts",
                        checked = notificationSettings.vibrationEnabled,
                        onCheckedChange = {
                            viewModel.updateNotificationSettings(notificationSettings.copy(vibrationEnabled = it))
                        },
                        tag = "toggle_vibration"
                    )

                    NotificationToggleRow(
                        title = "Override 'Do Not Disturb'",
                        subtitle = "Bypass silent mode for Life-Threatening Tornado warnings",
                        checked = notificationSettings.overrideDoNotDisturb,
                        onCheckedChange = {
                            viewModel.updateNotificationSettings(notificationSettings.copy(overrideDoNotDisturb = it))
                        },
                        tag = "toggle_dnd_override"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Minimum Lead Time Selector
                    Text(
                        text = "Minimum Radar Lead Time: ${notificationSettings.minimumLeadTimeMinutes} Minutes",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Alerts dispatch before projected storm arrival",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(15, 30, 45, 60).forEach { mins ->
                            val selected = notificationSettings.minimumLeadTimeMinutes == mins
                            OutlinedButton(
                                onClick = {
                                    viewModel.updateNotificationSettings(
                                        notificationSettings.copy(minimumLeadTimeMinutes = mins)
                                    )
                                },
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (selected) StormCyanContainer else Color.Transparent,
                                    contentColor = if (selected) StormCyanPrimary else TextSecondary
                                ),
                                border = BorderStroke(1.dp, if (selected) StormCyanPrimary else StormBorder),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("${mins}m", fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = TextTertiary)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = StormCyanPrimary,
                uncheckedTrackColor = StormSurfaceVariant
            ),
            modifier = Modifier.testTag(tag)
        )
    }
}

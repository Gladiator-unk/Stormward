package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EmergencyShelter
import com.example.data.model.StormTrajectory
import com.example.ui.theme.*
import com.example.ui.viewmodel.StormWardViewModel
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun RadarMapScreen(
    viewModel: StormWardViewModel,
    modifier: Modifier = Modifier
) {
    val currentWeather by viewModel.currentWeather.collectAsState()
    val trajectories by viewModel.stormTrajectories.collectAsState()
    val selectedTrajectory by viewModel.selectedTrajectory.collectAsState()
    val shelters by viewModel.emergencyShelters.collectAsState()
    val selectedShelter by viewModel.selectedShelter.collectAsState()
    val timeOffset by viewModel.radarTimeOffset.collectAsState()
    val isPlaying by viewModel.isRadarPlaying.collectAsState()

    val showRadarDbz by viewModel.showRadarDbz.collectAsState()
    val showCone by viewModel.showTrajectoryCone.collectAsState()
    val showLightning by viewModel.showLightning.collectAsState()
    val showShelters by viewModel.showShelters.collectAsState()
    val showWind by viewModel.showWindVectors.collectAsState()
    val isOffline by viewModel.isOfflineSimulated.collectAsState()

    // Pulse animation for active rotating mesocyclone & radar sweep
    val infiniteTransition = rememberInfiniteTransition(label = "RadarSweep")
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4000, easing = LinearEasing)
        ),
        label = "sweep"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val textMeasurer = rememberTextMeasurer()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(StormDarkBg)
    ) {
        // Top Radar Status Header & Layer Controls
        Surface(
            color = StormSurface,
            tonalElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (isOffline) SevereAmber else StormEmerald)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isOffline) "OFFLINE MAP MODE (Cached Tiles)" else "LIVE DOPPLER RADAR • NEXRAD LEVEL-II",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isOffline) SevereAmber else StormEmerald,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Mode Toggle (Online / Offline simulation)
                    OutlinedButton(
                        onClick = { viewModel.toggleOfflineSimulated() },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier
                            .height(28.dp)
                            .testTag("toggle_offline_mode_button")
                    ) {
                        Text(
                            text = if (isOffline) "Go Live" else "Test Offline",
                            style = MaterialTheme.typography.labelSmall,
                            color = StormCyanPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Layer Toggle Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = showRadarDbz,
                        onClick = { viewModel.toggleLayer("radar") },
                        label = { Text("Radar dBZ", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Waves, null, modifier = Modifier.size(16.dp)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StormCyanContainer,
                            selectedLabelColor = StormCyanPrimary
                        ),
                        modifier = Modifier.testTag("layer_radar_chip")
                    )
                    FilterChip(
                        selected = showCone,
                        onClick = { viewModel.toggleLayer("cone") },
                        label = { Text("Trajectory Cone", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Timeline, null, modifier = Modifier.size(16.dp)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SevereAmberContainer,
                            selectedLabelColor = SevereAmber
                        ),
                        modifier = Modifier.testTag("layer_cone_chip")
                    )
                    FilterChip(
                        selected = showLightning,
                        onClick = { viewModel.toggleLayer("lightning") },
                        label = { Text("Lightning (${currentWeather.lightningStrikesNearby})", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Bolt, null, modifier = Modifier.size(16.dp)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SevereDangerContainer,
                            selectedLabelColor = SevereDanger
                        ),
                        modifier = Modifier.testTag("layer_lightning_chip")
                    )
                    FilterChip(
                        selected = showShelters,
                        onClick = { viewModel.toggleLayer("shelters") },
                        label = { Text("Shelters (${shelters.size})", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Shield, null, modifier = Modifier.size(16.dp)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StormSurfaceVariant,
                            selectedLabelColor = StormEmerald
                        ),
                        modifier = Modifier.testTag("layer_shelters_chip")
                    )
                    FilterChip(
                        selected = showWind,
                        onClick = { viewModel.toggleLayer("wind") },
                        label = { Text("Wind Vectors", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Air, null, modifier = Modifier.size(16.dp)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StormSurfaceVariant,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("layer_wind_chip")
                    )
                }
            }
        }

        // Radar Canvas Box
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF040810))
                .pointerInput(trajectories, shelters) {
                    detectTapGestures { tapOffset ->
                        val tapXPercent = tapOffset.x / size.width
                        val tapYPercent = tapOffset.y / size.height

                        // Check if a trajectory was tapped
                        var foundTrajectory: StormTrajectory? = null
                        for (traj in trajectories) {
                            val dx = traj.currentXPercent - tapXPercent
                            val dy = traj.currentYPercent - tapYPercent
                            if (dx * dx + dy * dy < 0.04f) { // ~20% radius
                                foundTrajectory = traj
                                break
                            }
                        }
                        viewModel.selectTrajectory(foundTrajectory)

                        // Check if a shelter was tapped
                        var foundShelter: EmergencyShelter? = null
                        for (sh in shelters) {
                            val dx = sh.xPercent - tapXPercent
                            val dy = sh.yPercent - tapYPercent
                            if (dx * dx + dy * dy < 0.02f) {
                                foundShelter = sh
                                break
                            }
                        }
                        viewModel.selectShelter(foundShelter)
                    }
                }
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("radar_interactive_canvas")
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val center = Offset(canvasWidth * 0.5f, canvasHeight * 0.5f)

                // 1. Draw Map Grid & Distance Perimeter Rings
                val ringRadii = listOf(0.18f, 0.36f, 0.54f, 0.72f)
                ringRadii.forEachIndexed { index, frac ->
                    val r = canvasWidth.coerceAtMost(canvasHeight) * frac
                    drawCircle(
                        color = StormBorder.copy(alpha = 0.5f),
                        radius = r,
                        center = center,
                        style = Stroke(width = 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f))
                    )
                    val label = when (index) {
                        0 -> "15 mi"
                        1 -> "30 mi"
                        2 -> "45 mi"
                        else -> "60 mi"
                    }
                    drawText(
                        textMeasurer = textMeasurer,
                        text = label,
                        topLeft = Offset(center.x + r - 35f, center.y + 4f),
                        style = TextStyle(color = TextTertiary, fontSize = 9.sp)
                    )
                }

                // Crosshairs
                drawLine(
                    color = StormBorder.copy(alpha = 0.4f),
                    start = Offset(center.x, 0f),
                    end = Offset(center.x, canvasHeight),
                    strokeWidth = 1f
                )
                drawLine(
                    color = StormBorder.copy(alpha = 0.4f),
                    start = Offset(0f, center.y),
                    end = Offset(canvasWidth, center.y),
                    strokeWidth = 1f
                )

                // 2. Simulated Dynamic Radar Sweep Beam
                if (!isOffline) {
                    val sweepRad = Math.toRadians(sweepAngle.toDouble())
                    val sweepX = center.x + (canvasWidth * 0.8f) * cos(sweepRad).toFloat()
                    val sweepY = center.y + (canvasHeight * 0.8f) * sin(sweepRad).toFloat()
                    drawLine(
                        brush = Brush.linearGradient(
                            colors = listOf(StormCyanPrimary.copy(alpha = 0.7f), Color.Transparent),
                            start = center,
                            end = Offset(sweepX, sweepY)
                        ),
                        start = center,
                        end = Offset(sweepX, sweepY),
                        strokeWidth = 2.dp.toPx()
                    )
                }

                // 3. Draw Radar Reflectivity dBZ Storm Blobs (offset shifted by timeOffset scrubber)
                if (showRadarDbz) {
                    val shiftFrac = (timeOffset / 60f) * 0.12f
                    trajectories.forEach { traj ->
                        val stormCenter = Offset(
                            (traj.currentXPercent + shiftFrac) * canvasWidth,
                            (traj.currentYPercent - shiftFrac) * canvasHeight
                        )

                        // Multi-layer radar reflectivity contours
                        // Core 65+ dBZ (Pink/Magenta severe core)
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(RadarPink, RadarPurple, Color.Transparent),
                                center = stormCenter,
                                radius = 45.dp.toPx()
                            ),
                            radius = 45.dp.toPx(),
                            center = stormCenter
                        )
                        // Intense 50-60 dBZ (Red/Orange hail & heavy rain)
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(RadarRed.copy(alpha = 0.7f), RadarOrange.copy(alpha = 0.5f), Color.Transparent),
                                center = stormCenter,
                                radius = 80.dp.toPx()
                            ),
                            radius = 80.dp.toPx(),
                            center = stormCenter
                        )
                        // Moderate 30-45 dBZ (Yellow/Green rainband)
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(RadarYellow.copy(alpha = 0.5f), RadarGreen.copy(alpha = 0.35f), Color.Transparent),
                                center = stormCenter,
                                radius = 125.dp.toPx()
                            ),
                            radius = 125.dp.toPx(),
                            center = stormCenter
                        )
                    }
                }

                // 4. Draw Trajectory Paths & Cone of Uncertainty
                if (showCone) {
                    trajectories.forEach { traj ->
                        val startPt = Offset(traj.currentXPercent * canvasWidth, traj.currentYPercent * canvasHeight)
                        val waypoints = traj.waypoints

                        if (waypoints.isNotEmpty()) {
                            val path = Path()
                            path.moveTo(startPt.x, startPt.y)

                            // Draw Cone of uncertainty polygon
                            val topPoints = mutableListOf<Offset>()
                            val bottomPoints = mutableListOf<Offset>()

                            topPoints.add(startPt)
                            bottomPoints.add(startPt)

                            waypoints.forEach { wp ->
                                val pt = Offset(wp.xPercent * canvasWidth, wp.yPercent * canvasHeight)
                                val conePx = wp.coneRadiusDp.dp.toPx()
                                topPoints.add(Offset(pt.x, pt.y - conePx))
                                bottomPoints.add(Offset(pt.x, pt.y + conePx))
                            }

                            val conePath = Path()
                            conePath.moveTo(topPoints.first().x, topPoints.first().y)
                            for (i in 1 until topPoints.size) {
                                conePath.lineTo(topPoints[i].x, topPoints[i].y)
                            }
                            for (i in bottomPoints.indices.reversed()) {
                                conePath.lineTo(bottomPoints[i].x, bottomPoints[i].y)
                            }
                            conePath.close()

                            // Cone gradient fill
                            drawPath(
                                path = conePath,
                                brush = Brush.linearGradient(
                                    colors = listOf(SevereDanger.copy(alpha = 0.28f), SevereAmber.copy(alpha = 0.12f), Color.Transparent),
                                    start = startPt,
                                    end = Offset(waypoints.last().xPercent * canvasWidth, waypoints.last().yPercent * canvasHeight)
                                )
                            )

                            // Center Trajectory Vector Line
                            val trajLinePath = Path()
                            trajLinePath.moveTo(startPt.x, startPt.y)
                            waypoints.forEach { wp ->
                                trajLinePath.lineTo(wp.xPercent * canvasWidth, wp.yPercent * canvasHeight)
                            }
                            drawPath(
                                path = trajLinePath,
                                color = SevereAmber,
                                style = Stroke(
                                    width = 3.dp.toPx(),
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 12f), 0f)
                                )
                            )

                            // Waypoint Markers & Timestamps
                            waypoints.forEach { wp ->
                                val wpPt = Offset(wp.xPercent * canvasWidth, wp.yPercent * canvasHeight)
                                drawCircle(color = SevereAmber, radius = 6.dp.toPx(), center = wpPt)
                                drawCircle(color = StormDarkBg, radius = 3.dp.toPx(), center = wpPt)

                                drawText(
                                    textMeasurer = textMeasurer,
                                    text = "${wp.timeLabel} (${wp.estimatedWindMph}mph)",
                                    topLeft = Offset(wpPt.x + 8f, wpPt.y - 14f),
                                    style = TextStyle(color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }

                // 5. Draw Wind Vectors
                if (showWind) {
                    val arrowSpacing = 90.dp.toPx()
                    var x = 40.dp.toPx()
                    while (x < canvasWidth) {
                        var y = 60.dp.toPx()
                        while (y < canvasHeight) {
                            val windAngle = Math.toRadians(-45.0) // Moving NE
                            val arrowLen = 14.dp.toPx()
                            val ex = x + arrowLen * cos(windAngle).toFloat()
                            val ey = y + arrowLen * sin(windAngle).toFloat()

                            drawLine(
                                color = TextTertiary.copy(alpha = 0.4f),
                                start = Offset(x, y),
                                end = Offset(ex, ey),
                                strokeWidth = 1.5.dp.toPx()
                            )
                            drawCircle(
                                color = TextTertiary.copy(alpha = 0.4f),
                                radius = 2.dp.toPx(),
                                center = Offset(ex, ey)
                            )
                            y += arrowSpacing
                        }
                        x += arrowSpacing
                    }
                }

                // 6. Draw Lightning Flash strikes
                if (showLightning) {
                    val lightningOffsets = listOf(
                        Offset(canvasWidth * 0.35f, canvasHeight * 0.62f),
                        Offset(canvasWidth * 0.30f, canvasHeight * 0.72f),
                        Offset(canvasWidth * 0.42f, canvasHeight * 0.58f),
                        Offset(canvasWidth * 0.22f, canvasHeight * 0.38f)
                    )
                    lightningOffsets.forEach { loc ->
                        drawCircle(
                            color = Color(0xFFFFD600).copy(alpha = pulseAlpha),
                            radius = 12.dp.toPx(),
                            center = loc
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 3.5.dp.toPx(),
                            center = loc
                        )
                    }
                }

                // 7. Draw Emergency Shelters
                if (showShelters) {
                    shelters.forEach { sh ->
                        val shPt = Offset(sh.xPercent * canvasWidth, sh.yPercent * canvasHeight)
                        drawCircle(
                            color = StormEmerald,
                            radius = 9.dp.toPx(),
                            center = shPt
                        )
                        drawCircle(
                            color = Color(0xFF064E3B),
                            radius = 6.dp.toPx(),
                            center = shPt
                        )
                        drawText(
                            textMeasurer = textMeasurer,
                            text = "🛡️ ${sh.name.take(14)}...",
                            topLeft = Offset(shPt.x + 12f, shPt.y - 8f),
                            style = TextStyle(color = StormEmerald, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                        )
                    }
                }

                // 8. User Monitored Center Location Beacon
                drawCircle(
                    color = StormCyanPrimary.copy(alpha = 0.25f),
                    radius = 24.dp.toPx() * (1f + (pulseAlpha - 0.3f)),
                    center = center
                )
                drawCircle(
                    color = StormCyanPrimary,
                    radius = 7.dp.toPx(),
                    center = center
                )
                drawCircle(
                    color = Color.White,
                    radius = 3.dp.toPx(),
                    center = center
                )
                drawText(
                    textMeasurer = textMeasurer,
                    text = "YOU (${currentWeather.locationName})",
                    topLeft = Offset(center.x - 50f, center.y + 12f),
                    style = TextStyle(color = StormCyanPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                )
            }

            // Overlay Legend (dBZ Reflectivity Intensity Bar)
            Surface(
                color = StormDarkBg.copy(alpha = 0.85f),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, StormBorder),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text("dBZ Reflectivity", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(14.dp, 8.dp).background(RadarGreen))
                        Box(modifier = Modifier.size(14.dp, 8.dp).background(RadarYellow))
                        Box(modifier = Modifier.size(14.dp, 8.dp).background(RadarOrange))
                        Box(modifier = Modifier.size(14.dp, 8.dp).background(RadarRed))
                        Box(modifier = Modifier.size(14.dp, 8.dp).background(RadarPurple))
                        Box(modifier = Modifier.size(14.dp, 8.dp).background(RadarPink))
                    }
                    Row(
                        modifier = Modifier.width(84.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("20", fontSize = 8.sp, color = TextTertiary)
                        Text("40", fontSize = 8.sp, color = TextTertiary)
                        Text("65+", fontSize = 8.sp, color = TextTertiary)
                    }
                }
            }

            // Radar Bearing & Speed HUD
            selectedTrajectory?.let { traj ->
                Surface(
                    color = StormSurface.copy(alpha = 0.92f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, SevereAmber.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = SevereDanger, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ROTATING CELL", style = MaterialTheme.typography.labelSmall, color = SevereAmber, fontWeight = FontWeight.Bold)
                        }
                        Text(
                            text = "${traj.speedMph} mph • ${traj.headingDegrees}° (${traj.headingCompass})",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Intensity: ${traj.intensityDbz} dBZ • ⚡ ${traj.lightningStrikesPerMin}/min",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Radar Playback & Time Scrubber Control Bar
        Surface(
            color = StormSurface,
            tonalElevation = 6.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { viewModel.toggleRadarPlayback() },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(StormCyanContainer)
                                .testTag("radar_play_pause_button")
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause Radar" else "Play Radar Time-Lapse",
                                tint = StormCyanPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (timeOffset == 0) "LIVE NOW" else if (timeOffset > 0) "+$timeOffset MIN FORECAST" else "$timeOffset MIN PAST",
                                style = MaterialTheme.typography.titleSmall,
                                color = if (timeOffset == 0) StormEmerald else if (timeOffset > 0) SevereAmber else TextSecondary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Doppler Loop Time-Lapse",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextTertiary
                            )
                        }
                    }

                    Text(
                        text = "Step ±15m",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiary
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Time Offset Scrubber Chips
                val timeSteps = listOf(-60, -45, -30, -15, 0, 15, 30, 45, 60)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    timeSteps.forEach { step ->
                        val isSelected = timeOffset == step
                        val chipText = when {
                            step == 0 -> "NOW"
                            step > 0 -> "+${step}m"
                            else -> "${step}m"
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    when {
                                        isSelected && step == 0 -> StormEmerald
                                        isSelected && step > 0 -> SevereAmber
                                        isSelected -> StormCyanPrimary
                                        else -> StormSurfaceVariant
                                    }
                                )
                                .clickable { viewModel.setRadarTimeOffset(step) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = chipText,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) Color.Black else TextPrimary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        // Selected Object Information Drawer
        AnimatedVisibility(visible = selectedTrajectory != null || selectedShelter != null) {
            Surface(
                color = StormSurfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    selectedTrajectory?.let { traj ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = traj.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = SevereDanger,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${traj.category} • Moving ${traj.headingCompass} at ${traj.speedMph} mph",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                    Text(
                                        text = "⚡ Strikes: ${traj.lightningStrikesPerMin}/min",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = SevereAmber
                                    )
                                    Text(
                                        text = if (traj.mesocycloneDetected) "🌪️ Mesocyclone ACTIVE" else "No Shear",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (traj.mesocycloneDetected) SevereDanger else StormEmerald,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            IconButton(onClick = { viewModel.selectTrajectory(null) }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                            }
                        }
                    }

                    selectedShelter?.let { sh ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = sh.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = StormEmerald,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${sh.address} (${sh.distanceMiles} miles away)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("Capacity: ${sh.capacity}", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
                                    Text(if (sh.isUnderground) "✓ Underground" else "Reinforced Safe Room", style = MaterialTheme.typography.labelSmall, color = StormEmerald)
                                    if (sh.isPetFriendly) Text("🐾 Pets OK", style = MaterialTheme.typography.labelSmall, color = StormCyanPrimary)
                                }
                            }
                            IconButton(onClick = { viewModel.selectShelter(null) }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}

package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HistoricalStormData
import com.example.ui.theme.*
import com.example.ui.viewmodel.StormWardViewModel

@Composable
fun HistoryAnalyticsScreen(
    viewModel: StormWardViewModel,
    modifier: Modifier = Modifier
) {
    val historicalStorms = viewModel.historicalStorms
    val selectedStorm by viewModel.selectedHistoricalStorm.collectAsState()
    val textMeasurer = rememberTextMeasurer()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(StormDarkBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Historical Severe Storm Archive",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Post-event meteorological telemetry & barometric plunge analytics",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }

        // Horizontal selector for past events
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(historicalStorms) { storm ->
                    val isSelected = selectedStorm.id == storm.id
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) StormCyanContainer else StormSurface
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) StormCyanPrimary else StormBorder
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .width(220.dp)
                            .clickable { viewModel.selectHistoricalStorm(storm) }
                            .testTag("historical_storm_chip_${storm.id}")
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = storm.name,
                                style = MaterialTheme.typography.titleSmall,
                                color = if (isSelected) StormCyanPrimary else TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${storm.dateString} • ${storm.category}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Gust: ${storm.peakWindGustMph}mph", fontSize = 11.sp, color = SevereAmber, fontWeight = FontWeight.Bold)
                                Text("Min: ${storm.minPressureHpa}hPa", fontSize = 11.sp, color = SevereDanger, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Detailed Event Analysis Hero
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, StormBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = selectedStorm.name,
                        style = MaterialTheme.typography.headlineSmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${selectedStorm.category} • Recorded ${selectedStorm.dateString}",
                        style = MaterialTheme.typography.bodySmall,
                        color = SevereAmber
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = selectedStorm.summary,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // 4-Card Summary Metrics
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricCard(
                            label = "PEAK GUST",
                            value = "${selectedStorm.peakWindGustMph} mph",
                            icon = Icons.Default.Air,
                            color = SevereAmber
                        )
                        MetricCard(
                            label = "MIN PRESSURE",
                            value = "${selectedStorm.minPressureHpa} hPa",
                            icon = Icons.Default.Speed,
                            color = SevereDanger
                        )
                        MetricCard(
                            label = "MAX HAIL",
                            value = "${selectedStorm.maxHailDiameterInches}\"",
                            icon = Icons.Default.AcUnit,
                            color = StormCyanPrimary
                        )
                        MetricCard(
                            label = "RAINFALL",
                            value = "${selectedStorm.totalRainfallInches}\"",
                            icon = Icons.Default.WaterDrop,
                            color = StormEmerald
                        )
                    }
                }
            }
        }

        // Chart 1: Barometric Pressure Drop (hPa vs Hours Preceding Outbreak)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, StormBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Barometric Pressure Plunge Analysis",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Rapid hPa drop preceding cyclic tornado touchdown",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Icon(Icons.Default.TrendingDown, contentDescription = null, tint = SevereDanger)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Custom Canvas Line Chart for Pressure Drops
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .background(StormSurfaceVariant, RoundedCornerShape(8.dp))
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val data = selectedStorm.pressureHourlyDrops
                            val minVal = (data.minOrNull() ?: 980f) - 5f
                            val maxVal = (data.maxOrNull() ?: 1020f) + 5f
                            val range = maxVal - minVal

                            val chartWidth = size.width
                            val chartHeight = size.height

                            val points = data.mapIndexed { idx, value ->
                                val x = (idx.toFloat() / (data.size - 1)) * chartWidth
                                val normalizedY = 1f - ((value - minVal) / range)
                                val y = normalizedY * (chartHeight - 30f) + 15f
                                Offset(x, y)
                            }

                            // Draw gradient under curve
                            val fillPath = Path()
                            fillPath.moveTo(points.first().x, chartHeight)
                            points.forEach { fillPath.lineTo(it.x, it.y) }
                            fillPath.lineTo(points.last().x, chartHeight)
                            fillPath.close()

                            drawPath(
                                path = fillPath,
                                brush = Brush.verticalGradient(
                                    colors = listOf(SevereDanger.copy(alpha = 0.35f), Color.Transparent),
                                    startY = 0f,
                                    endY = chartHeight
                                )
                            )

                            // Draw line
                            val linePath = Path()
                            linePath.moveTo(points.first().x, points.first().y)
                            for (i in 1 until points.size) {
                                linePath.lineTo(points[i].x, points[i].y)
                            }
                            drawPath(
                                path = linePath,
                                color = SevereDanger,
                                style = Stroke(width = 3.dp.toPx())
                            )

                            // Draw points and values
                            points.forEachIndexed { idx, pt ->
                                drawCircle(color = SevereDanger, radius = 5.dp.toPx(), center = pt)
                                drawCircle(color = Color.White, radius = 2.5.dp.toPx(), center = pt)
                                val text = "${data[idx].toInt()}hPa"
                                drawText(
                                    textMeasurer = textMeasurer,
                                    text = text,
                                    topLeft = Offset(pt.x - 24f, pt.y - 20f),
                                    style = TextStyle(color = TextPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                )
                                drawText(
                                    textMeasurer = textMeasurer,
                                    text = "-${data.size - idx}h",
                                    topLeft = Offset(pt.x - 10f, chartHeight - 12f),
                                    style = TextStyle(color = TextTertiary, fontSize = 9.sp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Chart 2: Rainfall Accumulation Trend
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, StormBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Hourly Precipitation Accumulation",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Rainfall rates peaking at ${selectedStorm.totalRainfallInches} inches total",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .background(StormSurfaceVariant, RoundedCornerShape(8.dp))
                            .padding(16.dp)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val data = selectedStorm.rainfallHourlyInches
                            val maxVal = (data.maxOrNull() ?: 3.0f).coerceAtLeast(1.0f)
                            val barWidth = 24.dp.toPx()
                            val spacing = (size.width - (data.size * barWidth)) / (data.size + 1)

                            data.forEachIndexed { idx, value ->
                                val barHeight = (value / maxVal) * (size.height - 30f)
                                val left = spacing + idx * (barWidth + spacing)
                                val top = size.height - barHeight - 15f

                                drawRoundRect(
                                    color = StormCyanPrimary,
                                    topLeft = Offset(left, top),
                                    size = androidx.compose.ui.geometry.Size(barWidth, barHeight),
                                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
                                )

                                drawText(
                                    textMeasurer = textMeasurer,
                                    text = "${value}\"",
                                    topLeft = Offset(left, top - 14f),
                                    style = TextStyle(color = TextPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                )
                                drawText(
                                    textMeasurer = textMeasurer,
                                    text = "H${idx + 1}",
                                    topLeft = Offset(left + 4f, size.height - 12f),
                                    style = TextStyle(color = TextTertiary, fontSize = 9.sp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color
) {
    Surface(
        color = StormSurfaceVariant,
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = TextTertiary, fontSize = 9.sp)
            Text(value, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Bold)
        }
    }
}

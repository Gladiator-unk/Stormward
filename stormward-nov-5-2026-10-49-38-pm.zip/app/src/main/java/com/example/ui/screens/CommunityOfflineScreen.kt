package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.IncidentReportEntity
import com.example.data.model.OfflineMapPack
import com.example.data.model.SurvivalGuide
import com.example.ui.theme.*
import com.example.ui.viewmodel.StormWardViewModel
import com.example.util.ShareHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommunityOfflineScreen(
    viewModel: StormWardViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val communityReports by viewModel.communityReports.collectAsState()
    val offlinePacks by viewModel.offlinePacks.collectAsState()
    val survivalGuides = viewModel.survivalGuides
    val checklist by viewModel.checklist.collectAsState()

    var showReportDialog by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Community Feed, 1: Offline Maps, 2: Survival Guides

    Scaffold(
        containerColor = StormDarkBg,
        floatingActionButton = {
            if (selectedTab == 0) {
                ExtendedFloatingActionButton(
                    onClick = { showReportDialog = true },
                    containerColor = SevereDanger,
                    contentColor = Color.White,
                    icon = { Icon(Icons.Default.AddLocationAlt, contentDescription = null) },
                    text = { Text("Report Incident", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("report_incident_fab")
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Screen Section Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = StormSurface,
                contentColor = StormCyanPrimary,
                divider = { HorizontalDivider(color = StormBorder) }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Community (${communityReports.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_community")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Offline Maps", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.DownloadForOffline, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_offline_maps")
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Survival Guide", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.MedicalServices, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_survival_guide")
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Credits", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_credits")
                )
            }

            // Tab Content
            when (selectedTab) {
                0 -> CommunityFeedTab(
                    reports = communityReports,
                    onUpvote = { viewModel.upvoteReport(it) },
                    onShare = { ShareHelper.shareIncidentReport(context, it) }
                )
                1 -> OfflineMapsTab(
                    packs = offlinePacks,
                    onDownload = { viewModel.downloadOfflinePack(it) }
                )
                2 -> SurvivalGuidesTab(
                    guides = survivalGuides,
                    checklist = checklist,
                    onToggleChecklist = { viewModel.toggleChecklistItem(it) }
                )
                3 -> CreditsScreen()
            }
        }

        // New Incident Report Dialog / BottomSheet
        if (showReportDialog) {
            NewIncidentReportBottomSheet(
                onDismiss = { showReportDialog = false },
                onSubmit = { title, type, severity, desc, loc, hailOrFlood, name ->
                    viewModel.submitCommunityReport(title, type, severity, desc, loc, hailOrFlood, name)
                    showReportDialog = false
                }
            )
        }
    }
}

@Composable
fun CommunityFeedTab(
    reports: List<IncidentReportEntity>,
    onUpvote: (Long) -> Unit,
    onShare: (IncidentReportEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                border = BorderStroke(1.dp, StormBorder),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Radar, contentDescription = null, tint = StormCyanPrimary, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Decentralized Spotter Network", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("Ground truth storm reports saved locally & shared across peer networks", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                }
            }
        }

        items(reports, key = { it.id }) { report ->
            CommunityReportCard(
                report = report,
                onUpvote = { onUpvote(report.id) },
                onShare = { onShare(report) }
            )
        }
    }
}

@Composable
fun CommunityReportCard(
    report: IncidentReportEntity,
    onUpvote: () -> Unit,
    onShare: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = StormSurface),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            1.dp,
            if (report.severityLevel == "CRITICAL") SevereDanger else StormBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("community_report_card_${report.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = when (report.severityLevel) {
                        "CRITICAL" -> SevereDangerContainer
                        "HIGH" -> SevereAmberContainer
                        else -> StormSurfaceVariant
                    },
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = report.incidentType.replace('_', ' '),
                        style = MaterialTheme.typography.labelSmall,
                        color = when (report.severityLevel) {
                            "CRITICAL" -> SevereDanger
                            "HIGH" -> SevereAmber
                            else -> StormCyanPrimary
                        },
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${report.distanceMiles} mi away",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(onClick = onShare, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Share, contentDescription = "Share", tint = StormCyanPrimary, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = report.title,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "📍 ${report.locationName} • ${report.timestampFormatted}",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = report.description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(10.dp))
            Surface(
                color = StormSurfaceVariant,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Observed Severity / Size:", style = MaterialTheme.typography.labelSmall, color = TextTertiary)
                    Text(report.hailSizeOrFloodDepth, style = MaterialTheme.typography.labelSmall, color = SevereAmber, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (report.isVerifiedSpotter) Icons.Default.Verified else Icons.Default.Person,
                        contentDescription = null,
                        tint = if (report.isVerifiedSpotter) StormCyanPrimary else TextTertiary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${report.reporterName} ${if (report.isVerifiedSpotter) "✓ (Verified)" else ""}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (report.isVerifiedSpotter) StormCyanPrimary else TextSecondary
                    )
                }

                Button(
                    onClick = onUpvote,
                    enabled = !report.hasUserUpvoted,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (report.hasUserUpvoted) StormCyanContainer else StormSurfaceVariant,
                        contentColor = if (report.hasUserUpvoted) StormCyanPrimary else TextPrimary
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(Icons.Default.ThumbUp, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Verify (${report.upvoteCount})", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun OfflineMapsTab(
    packs: List<OfflineMapPack>,
    onDownload: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, StormEmerald.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CloudOff, contentDescription = null, tint = StormEmerald, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Zero-Cellular Offline Survivability", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("Cell towers frequently fail in tornadic downbursts. Downloaded maps store high-res vector tiles & verified shelter GPS coordinates.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                }
            }
        }

        items(packs) { pack ->
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, if (pack.isDownloaded) StormEmerald.copy(alpha = 0.5f) else StormBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(pack.regionName, style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text(pack.coverageArea, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("📦 ${pack.sizeMb} MB", style = MaterialTheme.typography.labelSmall, color = TextTertiary)
                            Text("🛡️ ${pack.shelterCount} Shelters Included", style = MaterialTheme.typography.labelSmall, color = StormEmerald)
                        }
                    }

                    if (pack.isDownloaded) {
                        Surface(
                            color = StormEmerald.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StormEmerald, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Cached", style = MaterialTheme.typography.labelSmall, color = StormEmerald, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Button(
                            onClick = { onDownload(pack.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = StormCyanPrimary, contentColor = Color.Black),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Download", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SurvivalGuidesTab(
    guides: List<SurvivalGuide>,
    checklist: List<com.example.data.model.ChecklistItem>,
    onToggleChecklist: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Attribution Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, StormBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Emergency Protocol Dispatcher", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                    Text("Engineered by Gladiator.unk prop. Shaik Uzair for life-safety compliance", style = MaterialTheme.typography.bodySmall, color = StormCyanPrimary)
                }
            }
        }

        // Checklist Section
        item {
            Text("Emergency Storm Prep Checklist", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
        }

        items(checklist) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (item.isChecked) StormEmerald.copy(alpha = 0.5f) else StormBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = item.isChecked,
                        onCheckedChange = { onToggleChecklist(item.id) },
                        colors = CheckboxDefaults.colors(
                            checkedColor = StormEmerald,
                            checkmarkColor = Color.Black
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (item.isChecked) TextTertiary else TextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(text = item.description, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }
            }
        }

        // Survival Guides
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text("Severe Storm Survival Tactics", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
        }

        items(guides) { guide ->
            Card(
                colors = CardDefaults.cardColors(containerColor = StormSurface),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, StormBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(guide.scenario, style = MaterialTheme.typography.titleMedium, color = SevereDanger, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("IMMEDIATE ACTION:", style = MaterialTheme.typography.labelSmall, color = StormEmerald, fontWeight = FontWeight.Bold)
                    Text(guide.immediateAction, style = MaterialTheme.typography.bodySmall, color = TextPrimary)

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("CRITICAL DANGER TO AVOID:", style = MaterialTheme.typography.labelSmall, color = SevereAmber, fontWeight = FontWeight.Bold)
                    Text(guide.dangerToAvoid, style = MaterialTheme.typography.bodySmall, color = TextSecondary)

                    Spacer(modifier = Modifier.height(10.dp))
                    guide.keyTips.forEach { tip ->
                        Row(modifier = Modifier.padding(vertical = 2.dp)) {
                            Text("• ", color = StormCyanPrimary, fontWeight = FontWeight.Bold)
                            Text(tip, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewIncidentReportBottomSheet(
    onDismiss: () -> Unit,
    onSubmit: (title: String, type: String, severity: String, description: String, location: String, measurement: String, reporter: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("TORNADO_SIGHTING") }
    var selectedSeverity by remember { mutableStateOf("CRITICAL") }
    var locationName by remember { mutableStateOf("") }
    var measurement by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var reporterName by remember { mutableStateOf("") }

    val incidentTypes = listOf(
        "TORNADO_SIGHTING" to "Tornado Sighting",
        "LARGE_HAIL" to "Large Hail",
        "DOWNED_POWERLINE" to "Downed Powerlines",
        "FLASH_FLOOD" to "Flash Flood",
        "STRUCTURAL_DAMAGE" to "Structural Damage"
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = StormSurface,
        dragHandle = { BottomSheetDefaults.DragHandle(color = StormBorder) }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Submit Severe Storm Incident Report",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Provide ground-truth observations to warn your local community",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            // Incident Type Selector
            Text("Hazard Type:", style = MaterialTheme.typography.labelMedium, color = TextTertiary)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                incidentTypes.take(3).forEach { (key, label) ->
                    val selected = selectedType == key
                    OutlinedButton(
                        onClick = { selectedType = key },
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (selected) StormCyanContainer else Color.Transparent,
                            contentColor = if (selected) StormCyanPrimary else TextSecondary
                        ),
                        border = BorderStroke(1.dp, if (selected) StormCyanPrimary else StormBorder),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(label, fontSize = 11.sp)
                    }
                }
            }

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Incident Headline (e.g. Funnel cloud touching down)") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = StormCyanPrimary,
                    unfocusedBorderColor = StormBorder
                ),
                modifier = Modifier.fillMaxWidth().testTag("input_incident_title")
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = locationName,
                    onValueChange = { locationName = it },
                    label = { Text("Location / Intersection") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = StormCyanPrimary,
                        unfocusedBorderColor = StormBorder
                    ),
                    modifier = Modifier.weight(1f).testTag("input_incident_location")
                )

                OutlinedTextField(
                    value = measurement,
                    onValueChange = { measurement = it },
                    label = { Text("Hail Size / Flood Depth") },
                    placeholder = { Text("e.g. 2.0\" hail") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = StormCyanPrimary,
                        unfocusedBorderColor = StormBorder
                    ),
                    modifier = Modifier.weight(1f).testTag("input_incident_measurement")
                )
            }

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Field Observations & Immediate Danger") },
                maxLines = 3,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = StormCyanPrimary,
                    unfocusedBorderColor = StormBorder
                ),
                modifier = Modifier.fillMaxWidth().testTag("input_incident_description")
            )

            OutlinedTextField(
                value = reporterName,
                onValueChange = { reporterName = it },
                label = { Text("Reporter / Spotter Call Sign") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = StormCyanPrimary,
                    unfocusedBorderColor = StormBorder
                ),
                modifier = Modifier.fillMaxWidth().testTag("input_incident_reporter")
            )

            Button(
                onClick = {
                    onSubmit(title, selectedType, selectedSeverity, description, locationName, measurement, reporterName)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = SevereDanger,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .testTag("submit_report_button")
            ) {
                Icon(Icons.Default.Send, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Broadcast Community Report", fontWeight = FontWeight.Bold)
            }
        }
    }
}

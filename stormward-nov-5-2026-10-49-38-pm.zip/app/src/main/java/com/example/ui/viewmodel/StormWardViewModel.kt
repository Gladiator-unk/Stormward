package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.IncidentReportEntity
import com.example.data.local.StormWardDatabase
import com.example.data.model.*
import com.example.data.repository.MonitoredCity
import com.example.data.repository.WeatherRepository
import com.example.util.NotificationHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class StormWardViewModel(application: Application) : AndroidViewModel(application) {

    private val database = StormWardDatabase.getInstance(application)
    private val repository = WeatherRepository(database.incidentReportDao())

    val availableCities: List<MonitoredCity> = repository.availableCities

    private val _selectedCityId = MutableStateFlow("okc")
    val selectedCityId: StateFlow<String> = _selectedCityId.asStateFlow()

    private val _currentWeather = MutableStateFlow(repository.getCurrentWeather("okc"))
    val currentWeather: StateFlow<CurrentWeather> = _currentWeather.asStateFlow()

    private val _activeAlerts = MutableStateFlow(repository.getActiveAlerts("okc"))
    val activeAlerts: StateFlow<List<SevereAlert>> = _activeAlerts.asStateFlow()

    private val _hourlyForecast = MutableStateFlow(repository.getHourlyForecast("okc"))
    val hourlyForecast: StateFlow<List<HourlyForecast>> = _hourlyForecast.asStateFlow()

    private val _dailyForecast = MutableStateFlow(repository.getDailyForecast("okc"))
    val dailyForecast: StateFlow<List<DailyForecast>> = _dailyForecast.asStateFlow()

    private val _airQuality = MutableStateFlow(repository.getAirQuality("okc"))
    val airQuality: StateFlow<AirQualityData> = _airQuality.asStateFlow()

    private val _stormTrajectories = MutableStateFlow(repository.getStormTrajectories("okc"))
    val stormTrajectories: StateFlow<List<StormTrajectory>> = _stormTrajectories.asStateFlow()

    private val _selectedTrajectory = MutableStateFlow<StormTrajectory?>(null)
    val selectedTrajectory: StateFlow<StormTrajectory?> = _selectedTrajectory.asStateFlow()

    private val _emergencyShelters = MutableStateFlow(repository.getEmergencyShelters("okc"))
    val emergencyShelters: StateFlow<List<EmergencyShelter>> = _emergencyShelters.asStateFlow()

    private val _selectedShelter = MutableStateFlow<EmergencyShelter?>(null)
    val selectedShelter: StateFlow<EmergencyShelter?> = _selectedShelter.asStateFlow()

    // Radar Map Interactive Controls
    private val _radarTimeOffset = MutableStateFlow(0) // 0 is NOW, -45, -30, -15, 0, +15, +30, +45, +60
    val radarTimeOffset: StateFlow<Int> = _radarTimeOffset.asStateFlow()

    private val _isRadarPlaying = MutableStateFlow(false)
    val isRadarPlaying: StateFlow<Boolean> = _isRadarPlaying.asStateFlow()

    // Map layer visibility toggles
    private val _showRadarDbz = MutableStateFlow(true)
    val showRadarDbz: StateFlow<Boolean> = _showRadarDbz.asStateFlow()

    private val _showTrajectoryCone = MutableStateFlow(true)
    val showTrajectoryCone: StateFlow<Boolean> = _showTrajectoryCone.asStateFlow()

    private val _showLightning = MutableStateFlow(true)
    val showLightning: StateFlow<Boolean> = _showLightning.asStateFlow()

    private val _showShelters = MutableStateFlow(true)
    val showShelters: StateFlow<Boolean> = _showShelters.asStateFlow()

    private val _showWindVectors = MutableStateFlow(true)
    val showWindVectors: StateFlow<Boolean> = _showWindVectors.asStateFlow()

    private val _isOfflineSimulated = MutableStateFlow(false)
    val isOfflineSimulated: StateFlow<Boolean> = _isOfflineSimulated.asStateFlow()

    // Offline map packages
    private val _offlinePacks = MutableStateFlow(repository.getOfflineMapPacks())
    val offlinePacks: StateFlow<List<OfflineMapPack>> = _offlinePacks.asStateFlow()

    // Historical Storms
    val historicalStorms: List<HistoricalStormData> = repository.getHistoricalStorms()
    private val _selectedHistoricalStorm = MutableStateFlow(historicalStorms.first())
    val selectedHistoricalStorm: StateFlow<HistoricalStormData> = _selectedHistoricalStorm.asStateFlow()

    // AQI Educational & Health Impact Reference Guides
    val aqiEducationalGuides: List<AqiLevelGuide> = repository.getAqiEducationalGuides()

    // Community Reports from Room DB
    val communityReports: StateFlow<List<IncidentReportEntity>> = repository.communityReportsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Notification Preferences
    private val _notificationSettings = MutableStateFlow(NotificationSettings())
    val notificationSettings: StateFlow<NotificationSettings> = _notificationSettings.asStateFlow()

    // Emergency prep checklist & guides
    val survivalGuides: List<SurvivalGuide> = repository.getSurvivalGuides()
    private val _checklist = MutableStateFlow(repository.getPrepChecklist())
    val checklist: StateFlow<List<ChecklistItem>> = _checklist.asStateFlow()

    // Last test notification feedback
    private val _testAlertStatus = MutableStateFlow<String?>(null)
    val testAlertStatus: StateFlow<String?> = _testAlertStatus.asStateFlow()

    private var radarPlaybackJob: Job? = null

    init {
        viewModelScope.launch {
            repository.seedInitialReportsIfEmpty()
            if (_stormTrajectories.value.isNotEmpty()) {
                _selectedTrajectory.value = _stormTrajectories.value.first()
            }
        }
    }

    fun selectCity(cityId: String) {
        _selectedCityId.value = cityId
        _currentWeather.value = repository.getCurrentWeather(cityId)
        _activeAlerts.value = repository.getActiveAlerts(cityId)
        _hourlyForecast.value = repository.getHourlyForecast(cityId)
        _dailyForecast.value = repository.getDailyForecast(cityId)
        _airQuality.value = repository.getAirQuality(cityId)
        _stormTrajectories.value = repository.getStormTrajectories(cityId)
        _emergencyShelters.value = repository.getEmergencyShelters(cityId)
        _selectedTrajectory.value = _stormTrajectories.value.firstOrNull()
        _selectedShelter.value = null
    }

    fun selectTrajectory(trajectory: StormTrajectory?) {
        _selectedTrajectory.value = trajectory
    }

    fun selectShelter(shelter: EmergencyShelter?) {
        _selectedShelter.value = shelter
    }

    fun selectHistoricalStorm(storm: HistoricalStormData) {
        _selectedHistoricalStorm.value = storm
    }

    fun setRadarTimeOffset(offset: Int) {
        _radarTimeOffset.value = offset
    }

    fun toggleRadarPlayback() {
        val willPlay = !_isRadarPlaying.value
        _isRadarPlaying.value = willPlay
        if (willPlay) {
            radarPlaybackJob?.cancel()
            radarPlaybackJob = viewModelScope.launch {
                val frames = listOf(-60, -45, -30, -15, 0, 15, 30, 45, 60)
                var idx = frames.indexOf(_radarTimeOffset.value).coerceAtLeast(0)
                while (isActive && _isRadarPlaying.value) {
                    delay(800)
                    idx = (idx + 1) % frames.size
                    _radarTimeOffset.value = frames[idx]
                }
            }
        } else {
            radarPlaybackJob?.cancel()
        }
    }

    fun toggleLayer(layerKey: String) {
        when (layerKey) {
            "radar" -> _showRadarDbz.value = !_showRadarDbz.value
            "cone" -> _showTrajectoryCone.value = !_showTrajectoryCone.value
            "lightning" -> _showLightning.value = !_showLightning.value
            "shelters" -> _showShelters.value = !_showShelters.value
            "wind" -> _showWindVectors.value = !_showWindVectors.value
        }
    }

    fun toggleOfflineSimulated() {
        _isOfflineSimulated.value = !_isOfflineSimulated.value
    }

    fun downloadOfflinePack(packId: String) {
        _offlinePacks.update { list ->
            list.map { pack ->
                if (pack.id == packId) pack.copy(isDownloaded = true) else pack
            }
        }
    }

    fun toggleChecklistItem(id: String) {
        _checklist.update { list ->
            list.map { item ->
                if (item.id == id) item.copy(isChecked = !item.isChecked) else item
            }
        }
    }

    fun updateNotificationSettings(newSettings: NotificationSettings) {
        _notificationSettings.value = newSettings
    }

    fun simulatePushAlert(context: Context) {
        val alert = _activeAlerts.value.firstOrNull() ?: SevereAlert(
            id = "alert_test_${System.currentTimeMillis()}",
            hazardType = HazardType.TORNADO,
            severity = AlertSeverity.EXTREME,
            title = "TEST: Tornado Warning In Effect",
            headline = "Radar confirmed rotation moving towards your monitored perimeter at 45 mph.",
            issuedTime = "Just now",
            expiresTime = "In 45 minutes",
            description = "Simulated severe weather push dispatch from StormWard alert engine.",
            actionRecommended = "Move to reinforced safe room or basement immediately. Avoid windows.",
            affectedZones = listOf("Local Warning Area"),
            maxWindGustMph = 80,
            hailSizeInches = 2.0f,
            distanceMiles = 4.2f,
            bearing = "SW"
        )

        val sent = NotificationHelper.sendSevereAlertNotification(
            context = context,
            alert = alert,
            vibrationEnabled = _notificationSettings.value.vibrationEnabled,
            soundEnabled = _notificationSettings.value.soundEnabled
        )

        _testAlertStatus.value = if (sent) {
            "✓ Live severe alert notification dispatched to status bar!"
        } else {
            "Notification posted (or request notification permission if Android 13+)"
        }

        viewModelScope.launch {
            delay(4000)
            _testAlertStatus.value = null
        }
    }

    fun submitCommunityReport(
        title: String,
        incidentType: String,
        severityLevel: String,
        description: String,
        locationName: String,
        hailOrFlood: String,
        reporterName: String
    ) {
        viewModelScope.launch {
            val entity = IncidentReportEntity(
                title = title.ifBlank { "Severe Weather Observation" },
                incidentType = incidentType,
                severityLevel = severityLevel,
                description = description.ifBlank { "Storm damage observed in local sector." },
                locationName = locationName.ifBlank { _currentWeather.value.locationName },
                distanceMiles = 1.2f,
                hailSizeOrFloodDepth = hailOrFlood.ifBlank { "Unspecified" },
                timestampFormatted = "Just now",
                reporterName = reporterName.ifBlank { "Community Spotter" },
                isVerifiedSpotter = false,
                upvoteCount = 1
            )
            repository.submitReport(entity)
        }
    }

    fun upvoteReport(reportId: Long) {
        viewModelScope.launch {
            repository.upvoteReport(reportId)
        }
    }
}

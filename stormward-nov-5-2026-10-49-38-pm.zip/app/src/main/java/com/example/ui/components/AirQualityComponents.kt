package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AirQualityData
import com.example.data.model.AqiCategory
import com.example.data.model.AqiLevelGuide
import com.example.data.model.SurroundingAqiStation
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AqiCircularGauge(
    aqi: Int,
    category: AqiCategory,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.size(130.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 12.dp.toPx()
            val diameter = size.minDimension - strokeWidth
            val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
            val arcSize = Size(diameter, diameter)

            // Base track
            drawArc(
                color = StormBorder,
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Dynamic progress arc
            val progressFrac = (aqi.toFloat() / 300f).coerceIn(0.05f, 1f)
            val sweep = 270f * progressFrac

            drawArc(
                color = Color(category.colorHex),
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "$aqi",
                style = MaterialTheme.typography.headlineMedium,
                color = Color(category.colorHex),
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = "AQI",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun SurroundingAqiStationCard(
    station: SurroundingAqiStation,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = StormSurfaceVariant),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, StormBorder),
        modifier = modifier
            .fillMaxWidth()
            .testTag("surrounding_station_${station.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = station.stationName,
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "📍 ${station.distanceMiles} mi ${station.direction} • Dominant: ${station.dominantPollutant}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Text(
                    text = "Trend: ${station.trend}",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (station.trend.contains("Rising")) SevereDanger else StormEmerald
                )
            }

            Surface(
                color = Color(station.category.colorHex).copy(alpha = 0.2f),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, Color(station.category.colorHex))
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "${station.aqi}",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color(station.category.colorHex),
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = station.category.name.take(4),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(station.category.colorHex),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun AqiLevelGuideItem(
    guide: AqiLevelGuide,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        colors = CardDefaults.cardColors(containerColor = StormSurfaceVariant),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Color(guide.category.colorHex).copy(alpha = 0.5f)),
        modifier = modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .testTag("aqi_guide_${guide.category.name}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .clip(CircleShape)
                            .background(Color(guide.category.colorHex))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = guide.category.label,
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Index Range: ${guide.rangeText}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(guide.category.colorHex),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = guide.description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    HorizontalDivider(color = StormBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "🩺 Potential Health Impacts:",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "• General Public: ${guide.generalPopulationImpact}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "• Sensitive Groups (Children, Elderly, Asthma/COPD, Cardiac): ${guide.sensitiveGroupsImpact}",
                        style = MaterialTheme.typography.bodySmall,
                        color = SevereAmber
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "🛡️ Recommended Protective Precautions:",
                        style = MaterialTheme.typography.labelMedium,
                        color = StormEmerald,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    guide.protectiveActions.forEach { action ->
                        Text(
                            text = "✓ $action",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AqiDetailBottomSheet(
    airQualityData: AirQualityData,
    guides: List<AqiLevelGuide>,
    onDismiss: () -> Unit
) {
    var subTab by remember { mutableIntStateOf(0) } // 0: Surrounding Areas, 1: Levels & Health Guide, 2: Pollutant Scale

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = StormSurface,
        dragHandle = { BottomSheetDefaults.DragHandle(color = StormBorder) }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp)
                .navigationBarsPadding()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Air Quality Intelligence Hub",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Regional sensors, health risk factors, & EPA thresholds",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sub Tab Row
            TabRow(
                selectedTabIndex = subTab,
                containerColor = StormSurfaceVariant,
                contentColor = StormCyanPrimary,
                modifier = Modifier.clip(RoundedCornerShape(10.dp))
            ) {
                Tab(
                    selected = subTab == 0,
                    onClick = { subTab = 0 },
                    text = { Text("Surrounding Stations (${airQualityData.surroundingStations.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = subTab == 1,
                    onClick = { subTab = 1 },
                    text = { Text("Health & Level Guide", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = subTab == 2,
                    onClick = { subTab = 2 },
                    text = { Text("Pollutants", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            when (subTab) {
                0 -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 450.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Text(
                                text = "Surrounding Sensor Stations (5–15 Mile Radius)",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Comparing nearby localized particulate concentrations",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                        }

                        items(airQualityData.surroundingStations) { station ->
                            SurroundingAqiStationCard(station = station)
                        }
                    }
                }
                1 -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 450.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Text(
                                text = "EPA Air Quality Index (AQI) Reference Scale",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Tap any category to inspect specific biological health impacts & clinical precautions.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                        }

                        items(guides) { guide ->
                            AqiLevelGuideItem(guide = guide)
                        }
                    }
                }
                2 -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Active Pollutant Breakdown & Biological Action",
                            style = MaterialTheme.typography.labelLarge,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )

                        PollutantDetailBar(
                            name = "Fine Inhalable Particles (PM2.5)",
                            value = "${airQualityData.pm25} µg/m³",
                            threshold = "WHO Guideline: 15 µg/m³ 24h",
                            fraction = (airQualityData.pm25 / 75f).coerceIn(0f, 1f),
                            impact = "Can penetrate deep into lung tissue and enter the bloodstream, aggravating heart disease."
                        )

                        PollutantDetailBar(
                            name = "Coarse Particles (PM10)",
                            value = "${airQualityData.pm10} µg/m³",
                            threshold = "WHO Guideline: 45 µg/m³ 24h",
                            fraction = (airQualityData.pm10 / 150f).coerceIn(0f, 1f),
                            impact = "Lofted by severe storm downbursts and outflow winds. Irritates eyes, nose, and upper airways."
                        )

                        PollutantDetailBar(
                            name = "Ground-Level Ozone (O3)",
                            value = "${airQualityData.o3} ppb",
                            threshold = "EPA Std: 70 ppb 8h",
                            fraction = (airQualityData.o3 / 100f).coerceIn(0f, 1f),
                            impact = "Strong lung irritant formed in pre-storm stagnant heat. Causes chest tightness and reduced vital capacity."
                        )

                        PollutantDetailBar(
                            name = "Nitrogen Dioxide (NO2)",
                            value = "${airQualityData.no2} ppb",
                            threshold = "EPA Std: 100 ppb 1h",
                            fraction = (airQualityData.no2 / 100f).coerceIn(0f, 1f),
                            impact = "Combustion gas causing increased susceptibility to respiratory infection."
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PollutantDetailBar(
    name: String,
    value: String,
    threshold: String,
    fraction: Float,
    impact: String
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = StormSurfaceVariant),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(name, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text(value, style = MaterialTheme.typography.bodyMedium, color = StormCyanPrimary, fontWeight = FontWeight.Bold)
            }
            Text(threshold, style = MaterialTheme.typography.labelSmall, color = TextTertiary)
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { fraction },
                color = if (fraction > 0.6f) SevereDanger else StormCyanPrimary,
                trackColor = StormBorder,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(impact, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
    }
}

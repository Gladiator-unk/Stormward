package com.example

import com.example.data.model.AqiCategory
import com.example.data.model.HazardType
import com.example.data.model.SevereRiskLevel
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun `aqi category colors and ranges are valid`() {
    assertEquals(6, AqiCategory.values().size)
    assertEquals(0xFF10B981, AqiCategory.GOOD.colorHex)
    assertEquals(0xFF881337, AqiCategory.HAZARDOUS.colorHex)
  }

  @Test
  fun `severe hazard types have valid display names`() {
    assertEquals("Tornado Warning", HazardType.TORNADO.displayName)
    assertEquals("Large Hail Warning", HazardType.HAIL.displayName)
    assertEquals("Flash Flood Warning", HazardType.FLASH_FLOOD.displayName)
  }

  @Test
  fun `severe risk levels are properly ranked`() {
    assertTrue(SevereRiskLevel.EXTREME.ordinal < SevereRiskLevel.LOW.ordinal)
  }
}

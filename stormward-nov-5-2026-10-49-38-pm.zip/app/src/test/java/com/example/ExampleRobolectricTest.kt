package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.IncidentReportEntity
import com.example.data.local.StormWardDatabase
import com.example.data.repository.WeatherRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app name string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("StormWard", appName)
  }

  @Test
  fun `weather repository provides real severe meteorological data`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val database = StormWardDatabase.getInstance(context)
    val repo = WeatherRepository(database.incidentReportDao())

    val weather = repo.getCurrentWeather("okc")
    assertEquals("Oklahoma City", weather.locationName)
    assertTrue("Wind gust should be elevated in severe weather", weather.windGustMph >= 50)
    assertTrue("Reflectivity should indicate severe storms", weather.radarReflectivityDbz >= 60)

    val alerts = repo.getActiveAlerts("okc")
    assertTrue("Should have active severe alerts", alerts.isNotEmpty())

    val aqi = repo.getAirQuality("okc")
    assertNotNull(aqi)
  }

  @Test
  fun `incident report dao persistence works in room`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val database = StormWardDatabase.getInstance(context)
    val dao = database.incidentReportDao()

    val testReport = IncidentReportEntity(
      title = "Funnel Cloud Observed",
      incidentType = "TORNADO_SIGHTING",
      severityLevel = "CRITICAL",
      description = "Visual rotation confirmed 2 miles SW.",
      locationName = "Highway 9 & I-35",
      distanceMiles = 2.0f,
      hailSizeOrFloodDepth = "Funnel Cloud",
      timestampFormatted = "Just now",
      reporterName = "Test Spotter",
      upvoteCount = 5
    )

    val id = dao.insertReport(testReport)
    assertTrue(id > 0)

    val reports = dao.getAllReportsFlow().first()
    assertTrue(reports.any { it.title == "Funnel Cloud Observed" })
  }

  @Test
  fun `air quality index tracking includes surrounding stations and health guides`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val database = StormWardDatabase.getInstance(context)
    val repo = WeatherRepository(database.incidentReportDao())

    val aqiData = repo.getAirQuality("okc")
    assertNotNull(aqiData)
    assertTrue("Should monitor surrounding stations", aqiData.surroundingStations.isNotEmpty())
    val firstStation = aqiData.surroundingStations.first()
    assertTrue("Station distance should be positive", firstStation.distanceMiles > 0f)
    assertNotNull(firstStation.trend)

    val guides = repo.getAqiEducationalGuides()
    assertEquals("Should cover all 6 EPA AQI levels", 6, guides.size)
    guides.forEach { guide ->
      assertTrue("Should have health impacts for general population", guide.generalPopulationImpact.isNotBlank())
      assertTrue("Should have health impacts for sensitive groups", guide.sensitiveGroupsImpact.isNotBlank())
      assertTrue("Should have protective actions", guide.protectiveActions.isNotEmpty())
    }
  }

  @Test
  fun `credits attribution string is properly formatted`() {
    val attribution = "made by Gladiator.unk aka Shaik UzairUzair"
    assertTrue(attribution.contains("Gladiator.unk"))
    assertTrue(attribution.contains("Shaik UzairUzair"))
  }
}
